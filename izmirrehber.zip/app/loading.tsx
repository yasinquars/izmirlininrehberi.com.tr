export default function Loading() {
  return (
    <div className="min-h-screen bg-gray-100">
      {/* Header Skeleton */}
      <div className="bg-white border-b">
        <div className="container mx-auto px-4 py-2">
          <div className="flex justify-between items-center">
            <div className="flex space-x-4">
              <div className="h-4 w-32 bg-gray-200 rounded animate-pulse"></div>
              <div className="h-4 w-32 bg-gray-200 rounded animate-pulse"></div>
            </div>
            <div className="h-4 w-48 bg-gray-200 rounded animate-pulse"></div>
          </div>
        </div>
      </div>

      {/* Main Header Skeleton */}
      <div className="bg-white shadow-sm">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center">
              <div className="w-12 h-12 bg-gray-200 rounded-lg animate-pulse mr-3"></div>
              <div className="h-8 w-32 bg-gray-200 rounded animate-pulse"></div>
            </div>
            <div className="flex space-x-3">
              <div className="h-10 w-32 bg-gray-200 rounded animate-pulse"></div>
              <div className="h-10 w-32 bg-gray-200 rounded animate-pulse"></div>
            </div>
          </div>
        </div>
      </div>

      {/* Navigation Skeleton */}
      <div className="bg-yellow-500">
        <div className="container mx-auto px-4">
          <div className="flex items-center justify-between py-4">
            <div className="flex space-x-8">
              {[1, 2, 3, 4].map((i) => (
                <div key={i} className="h-6 w-24 bg-yellow-400 rounded animate-pulse"></div>
              ))}
            </div>
            <div className="h-6 w-32 bg-yellow-400 rounded animate-pulse"></div>
          </div>
        </div>
      </div>

      {/* Hero Section Skeleton */}
      <div className="bg-gray-300 py-24">
        <div className="container mx-auto px-4 text-center">
          <div className="h-12 w-96 bg-gray-400 rounded mx-auto mb-4 animate-pulse"></div>
          <div className="h-6 w-64 bg-gray-400 rounded mx-auto mb-8 animate-pulse"></div>
          <div className="max-w-4xl mx-auto bg-white rounded-lg p-2 flex gap-2">
            <div className="flex-1 h-12 bg-gray-200 rounded animate-pulse"></div>
            <div className="flex-1 h-12 bg-gray-200 rounded animate-pulse"></div>
            <div className="h-12 w-32 bg-gray-200 rounded animate-pulse"></div>
          </div>
        </div>
      </div>

      {/* Category Icons Skeleton */}
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-7 -mt-12 relative z-10 gap-1">
          {[1, 2, 3, 4, 5, 6, 7].map((i) => (
            <div key={i} className="bg-gray-600 rounded p-4 text-center">
              <div className="h-8 w-8 bg-gray-500 rounded mx-auto mb-2 animate-pulse"></div>
              <div className="h-4 w-16 bg-gray-500 rounded mx-auto mb-1 animate-pulse"></div>
              <div className="h-3 w-12 bg-gray-500 rounded mx-auto animate-pulse"></div>
            </div>
          ))}
        </div>
      </div>

      {/* Main Content Skeleton */}
      <div className="container mx-auto px-4 py-12">
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
          {/* Sidebar Skeleton */}
          <div className="lg:col-span-1">
            <div className="bg-white rounded-lg shadow mb-6">
              <div className="bg-gray-200 p-4 rounded-t-lg">
                <div className="h-6 w-32 bg-gray-300 rounded animate-pulse"></div>
              </div>
              <div className="p-4 space-y-3">
                {[1, 2, 3, 4, 5, 6, 7, 8].map((i) => (
                  <div key={i} className="h-4 w-full bg-gray-200 rounded animate-pulse"></div>
                ))}
              </div>
            </div>
          </div>

          {/* Featured Companies Skeleton */}
          <div className="lg:col-span-3">
            <div className="bg-white rounded-lg shadow">
              <div className="bg-gray-200 p-4 rounded-t-lg">
                <div className="h-6 w-48 bg-gray-300 rounded animate-pulse"></div>
              </div>
              <div className="p-6">
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                  {[1, 2, 3, 4].map((i) => (
                    <div key={i} className="border rounded-lg p-4">
                      <div className="w-20 h-20 bg-gray-200 rounded-lg mx-auto mb-3 animate-pulse"></div>
                      <div className="h-4 w-24 bg-gray-200 rounded mx-auto mb-1 animate-pulse"></div>
                      <div className="h-3 w-16 bg-gray-200 rounded mx-auto mb-2 animate-pulse"></div>
                      <div className="h-3 w-20 bg-gray-200 rounded mx-auto animate-pulse"></div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
