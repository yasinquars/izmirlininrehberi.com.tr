"use client"

import { useState, useEffect } from "react"

interface Company {
  id: number
  name: string
  category: string
  description: string
  phone: string
  email: string
  address: string
  website?: string
  image: string
  rating: number
  reviews: number
  isGold: boolean
  isFeatured: boolean
  joinDate: string
}

// Kategori eşleştirme sistemi
const categoryMapping: { [key: string]: string[] } = {
  EĞİTİM: ["Eğitim"],
  HİZMET: ["Hizmet", "Temizlik Hizmetleri", "Güvenlik Hizmetleri", "Nakliye ve Taşımacılık"],
  İLETİŞİM: ["İletişim", "Medya", "Reklam"],
  İNŞAAT: ["İnşaat", "Yapı", "Mimarlık"],
  SAĞLIK: ["Sağlık", "Hastane", "Klinik", "Eczane"],
  TURİZM: ["Turizm", "Otel", "Seyahat"],
  "YEME-İÇME": ["Yeme-İçme", "Restoran", "Kafe", "Fast Food"],
  "BİLGİSAYAR - ELEKTRONİK": ["Bilişim & Teknoloji", "Bilgisayar", "Elektronik", "Yazılım"],
  OTOMOTİV: ["Otomotiv", "Araç", "Oto"],
  EMLAK: ["Emlak", "Gayrimenkul"],
  FINANS: ["Finans", "Banka", "Sigorta"],
  "TASARIM & REKLAM": ["Tasarım & Reklam", "Grafik", "Web Tasarım"],
}

// Bu component'i admin panelinden eklenen firmaları takip etmek için kullanabiliriz
export function useCategoryCount() {
  const [companies, setCompanies] = useState<Company[]>([])

  // LocalStorage'dan firmaları oku
  useEffect(() => {
    const savedCompanies = localStorage.getItem("companies")
    if (savedCompanies) {
      setCompanies(JSON.parse(savedCompanies))
    }
  }, [])

  // Kategori bazında firma sayısını hesapla
  const getCategoryCount = (categoryName: string) => {
    const mappedCategories = categoryMapping[categoryName] || [categoryName]
    return companies.filter((company) =>
      mappedCategories.some((cat) => company.category.toLowerCase().includes(cat.toLowerCase())),
    ).length
  }

  // Aktif kategori sayısını hesapla (firma bulunan kategoriler)
  const getActiveCategoryCount = () => {
    const activeCategories = new Set<string>()
    companies.forEach((company) => {
      // Her firma kategorisini kontrol et
      Object.keys(categoryMapping).forEach((mainCategory) => {
        const subCategories = categoryMapping[mainCategory]
        if (subCategories.some((sub) => company.category.toLowerCase().includes(sub.toLowerCase()))) {
          activeCategories.add(mainCategory)
        }
      })
    })
    return activeCategories.size
  }

  return { companies, getCategoryCount, getActiveCategoryCount }
}
