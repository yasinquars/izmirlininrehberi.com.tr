"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import {
  Search,
  Phone,
  Mail,
  Calendar,
  MapPin,
  Clock,
  Users,
  ChevronRight,
  Home,
  Briefcase,
  Filter,
  Star,
  ExternalLink,
  Loader2,
} from "lucide-react"
import Link from "next/link"

interface Event {
  id: number
  title: string
  description: string
  category: string
  date: string
  endDate?: string
  time: string
  location: string
  address: string
  organizer: string
  capacity?: number
  price: string
  image: string
  website?: string
  phone?: string
  email?: string
  isFeatured: boolean
  isUpcoming: boolean
  tags: string[]
}

interface SiteSettings {
  phone: string
  email: string
  heroImage: string
  logo: string
  siteName: string
}

export default function FuarEtkinliklerPage() {
  const [events, setEvents] = useState<Event[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const [siteSettings, setSiteSettings] = useState<SiteSettings>({
    phone: "0 850 303 81 08",
    email: "info@izmirrehber.com",
    heroImage: "",
    logo: "",
    siteName: "izmirrehber",
  })
  const [searchTerm, setSearchTerm] = useState("")
  const [selectedCategory, setSelectedCategory] = useState("all")
  const [sortBy, setSortBy] = useState("date")
  const [filterBy, setFilterBy] = useState("all")

  // Verileri yükle
  useEffect(() => {
    const loadData = async () => {
      try {
        setIsLoading(true)

        // Site ayarlarını yükle
        const savedSettings = localStorage.getItem("siteSettings")
        if (savedSettings) {
          setSiteSettings(JSON.parse(savedSettings))
        }

        // Etkinlikleri yükle
        const savedEvents = localStorage.getItem("events")
        if (savedEvents) {
          const parsedEvents = JSON.parse(savedEvents)
          setEvents(Array.isArray(parsedEvents) ? parsedEvents : [])
        } else {
          // Varsayılan etkinlikler
          const defaultEvents: Event[] = [
            {
              id: 1,
              title: "İzmir Teknoloji Fuarı 2024",
              description:
                "Teknoloji sektörünün en büyük buluşması. Yenilikçi ürünler, konferanslar ve networking fırsatları.",
              category: "Teknoloji",
              date: "2024-03-15",
              endDate: "2024-03-17",
              time: "09:00",
              location: "İzmir Fuar Merkezi",
              address: "Gaziemir, İzmir",
              organizer: "İzmir Teknoloji Derneği",
              capacity: 5000,
              price: "Ücretsiz",
              image: "/placeholder.svg?height=200&width=300&text=Teknoloji+Fuarı",
              website: "https://izmirteknolojifuari.com",
              phone: "0232 445 67 89",
              email: "info@izmirteknoloji.com",
              isFeatured: true,
              isUpcoming: true,
              tags: ["teknoloji", "yapay zeka", "blockchain"],
            },
            {
              id: 2,
              title: "İzmir Gıda ve İçecek Festivali",
              description:
                "Ege'nin en lezzetli festivali! Yerel üreticiler, şefler ve gastronomi tutkunları bir arada.",
              category: "Gastronomi",
              date: "2024-04-20",
              endDate: "2024-04-22",
              time: "10:00",
              location: "Kordon Boyu",
              address: "Alsancak, İzmir",
              organizer: "İzmir Büyükşehir Belediyesi",
              capacity: 10000,
              price: "50 TL",
              image: "/placeholder.svg?height=200&width=300&text=Gıda+Festivali",
              website: "https://izmirfoodfest.com",
              phone: "0232 293 46 46",
              email: "etkinlik@izmir.bel.tr",
              isFeatured: true,
              isUpcoming: true,
              tags: ["gastronomi", "yemek", "festival"],
            },
            {
              id: 3,
              title: "İzmir Girişimcilik Zirvesi",
              description: "Girişimciler, yatırımcılar ve mentorların buluşma noktası. Startup'lar için büyük fırsat.",
              category: "İş Dünyası",
              date: "2024-05-10",
              time: "13:00",
              location: "Hilton İzmir",
              address: "Alsancak, İzmir",
              organizer: "İzmir Kalkınma Ajansı",
              capacity: 500,
              price: "200 TL",
              image: "/placeholder.svg?height=200&width=300&text=Girişimcilik+Zirvesi",
              website: "https://izmirgirisimcilik.com",
              phone: "0232 489 10 00",
              email: "info@izmirgirisimcilik.com",
              isFeatured: false,
              isUpcoming: true,
              tags: ["girişimcilik", "yatırım", "networking"],
            },
            {
              id: 4,
              title: "İzmir Sanat ve Kültür Festivali",
              description:
                "Müze, galeri ve sanat merkezlerinde sergi, konser ve atölye çalışmaları ile dolu bir hafta.",
              category: "Kültür",
              date: "2024-06-01",
              endDate: "2024-06-15",
              time: "14:00",
              location: "Kültürpark",
              address: "Konak, İzmir",
              organizer: "İzmir Kültür ve Sanat Vakfı",
              capacity: 2000,
              price: "Ücretsiz",
              image: "/placeholder.svg?height=200&width=300&text=Sanat+Festivali",
              website: "https://izmirkultur.com",
              phone: "0232 484 60 45",
              email: "info@izmirkultur.com",
              isFeatured: true,
              isUpcoming: true,
              tags: ["sanat", "kültür", "sergi"],
            },
            {
              id: 5,
              title: "İzmir Sağlık ve Wellness Fuarı",
              description:
                "Sağlık teknolojileri, wellness ürünleri ve alternatif tıp uygulamalarının tanıtıldığı fuar.",
              category: "Sağlık",
              date: "2024-07-12",
              endDate: "2024-07-14",
              time: "09:30",
              location: "İzmir Fuar Merkezi",
              address: "Gaziemir, İzmir",
              organizer: "Sağlık Bakanlığı İzmir İl Müdürlüğü",
              capacity: 3000,
              price: "100 TL",
              image: "/placeholder.svg?height=200&width=300&text=Sağlık+Fuarı",
              website: "https://izmirsaglikfuari.com",
              phone: "0232 567 89 01",
              email: "info@izmirsaglikfuari.com",
              isFeatured: false,
              isUpcoming: true,
              tags: ["sağlık", "wellness", "teknoloji"],
            },
            {
              id: 6,
              title: "İzmir Eğitim ve Kariyer Fuarı",
              description: "Öğrenciler ve mezunlar için kariyer fırsatları. Üniversiteler ve şirketler bir arada.",
              category: "Eğitim",
              date: "2024-08-25",
              endDate: "2024-08-27",
              time: "10:00",
              location: "Ege Üniversitesi Kampüsü",
              address: "Bornova, İzmir",
              organizer: "Ege Üniversitesi",
              capacity: 8000,
              price: "Ücretsiz",
              image: "/placeholder.svg?height=200&width=300&text=Kariyer+Fuarı",
              website: "https://egekariyerfuari.com",
              phone: "0232 311 10 10",
              email: "kariyer@ege.edu.tr",
              isFeatured: true,
              isUpcoming: true,
              tags: ["eğitim", "kariyer", "üniversite"],
            },
            {
              id: 7,
              title: "İzmir Otomotiv Fuarı",
              description:
                "En yeni otomobil modelleri, elektrikli araçlar ve otomotiv teknolojilerinin sergilendiği fuar.",
              category: "Otomotiv",
              date: "2024-09-15",
              endDate: "2024-09-18",
              time: "10:00",
              location: "İzmir Fuar Merkezi",
              address: "Gaziemir, İzmir",
              organizer: "Otomotiv Sanayii Derneği",
              capacity: 12000,
              price: "75 TL",
              image: "/placeholder.svg?height=200&width=300&text=Otomotiv+Fuarı",
              website: "https://izmirotomotivfuari.com",
              phone: "0232 234 56 78",
              email: "info@otomotivfuari.com",
              isFeatured: false,
              isUpcoming: true,
              tags: ["otomotiv", "elektrikli araç", "teknoloji"],
            },
            {
              id: 8,
              title: "İzmir Turizm ve Seyahat Fuarı",
              description: "Türkiye ve dünya destinasyonları, otel zincirleri ve seyahat acentelerinin katıldığı fuar.",
              category: "Turizm",
              date: "2024-10-05",
              endDate: "2024-10-07",
              time: "09:00",
              location: "Fuar İzmir",
              address: "Gaziemir, İzmir",
              organizer: "Türkiye Seyahat Acenteleri Birliği",
              capacity: 4000,
              price: "60 TL",
              image: "/placeholder.svg?height=200&width=300&text=Turizm+Fuarı",
              website: "https://izmirturizmfuari.com",
              phone: "0232 345 67 89",
              email: "info@turizmfuari.com",
              isFeatured: true,
              isUpcoming: true,
              tags: ["turizm", "seyahat", "otel"],
            },
          ]
          setEvents(defaultEvents)
          localStorage.setItem("events", JSON.stringify(defaultEvents))
        }
      } catch (error) {
        console.error("Veri yükleme hatası:", error)
        setEvents([])
      } finally {
        setIsLoading(false)
      }
    }

    loadData()
  }, [])

  // Filtrelenmiş ve sıralanmış etkinlikler
  const getFilteredAndSortedEvents = () => {
    if (!Array.isArray(events)) return []

    let filtered = [...events]

    // Kategori filtresi
    if (selectedCategory !== "all") {
      filtered = filtered.filter((event) => event.category === selectedCategory)
    }

    // Durum filtresi
    if (filterBy === "upcoming") {
      filtered = filtered.filter((event) => event.isUpcoming)
    } else if (filterBy === "featured") {
      filtered = filtered.filter((event) => event.isFeatured)
    }

    // Arama filtresi
    if (searchTerm) {
      filtered = filtered.filter(
        (event) =>
          event.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
          event.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
          event.category.toLowerCase().includes(searchTerm.toLowerCase()) ||
          event.organizer.toLowerCase().includes(searchTerm.toLowerCase()),
      )
    }

    // Sıralama
    filtered.sort((a, b) => {
      switch (sortBy) {
        case "date":
          return new Date(a.date).getTime() - new Date(b.date).getTime()
        case "title":
          return a.title.localeCompare(b.title)
        case "category":
          return a.category.localeCompare(b.category)
        default:
          return 0
      }
    })

    return filtered
  }

  // Kategorileri al
  const getCategories = () => {
    if (!Array.isArray(events)) return []
    const categories = [...new Set(events.map((event) => event.category))]
    return categories.sort()
  }

  // Filtreleri temizle
  const clearFilters = () => {
    setSelectedCategory("all")
    setSearchTerm("")
    setFilterBy("all")
  }

  const filteredEvents = getFilteredAndSortedEvents()
  const categories = getCategories()

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gray-100 flex items-center justify-center">
        <div className="text-center">
          <Loader2 className="h-8 w-8 animate-spin mx-auto mb-4 text-purple-600" />
          <p className="text-gray-600">Etkinlikler yükleniyor...</p>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gray-100">
      {/* Top Header */}
      <div className="bg-white border-b">
        <div className="container mx-auto px-4 py-2">
          <div className="flex justify-between items-center text-sm">
            <div className="flex items-center space-x-6">
              <div className="flex items-center text-gray-600">
                <Mail className="h-4 w-4 mr-1" />
                {siteSettings.email}
              </div>
              <div className="flex items-center text-gray-600">
                <Phone className="h-4 w-4 mr-1" />
                {siteSettings.phone}
              </div>
            </div>
            <div className="flex items-center space-x-4">
              <div className="flex space-x-2">
                {/* Social Media Icons */}
                <div className="w-6 h-6 bg-blue-600 rounded-full flex items-center justify-center">
                  <span className="text-white text-xs">f</span>
                </div>
                <div className="w-6 h-6 bg-blue-400 rounded-full flex items-center justify-center">
                  <span className="text-white text-xs">t</span>
                </div>
                <div className="w-6 h-6 bg-red-600 rounded-full flex items-center justify-center">
                  <span className="text-white text-xs">g</span>
                </div>
                <div className="w-6 h-6 bg-blue-700 rounded-full flex items-center justify-center">
                  <span className="text-white text-xs">in</span>
                </div>
                <div className="w-6 h-6 bg-red-500 rounded-full flex items-center justify-center">
                  <span className="text-white text-xs">y</span>
                </div>
                <div className="w-6 h-6 bg-green-600 rounded-full flex items-center justify-center">
                  <span className="text-white text-xs">w</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Main Header */}
      <header className="bg-white shadow-sm">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-center">
            <div className="flex items-center">
              <div className="w-12 h-12 bg-yellow-500 rounded-lg flex items-center justify-center mr-3">
                <span className="text-white font-bold text-xl">İ</span>
              </div>
              <div>
                <h1 className="text-2xl font-bold text-gray-900">
                  izmir<span className="text-yellow-500">rehber</span>
                </h1>
              </div>
            </div>
          </div>
        </div>
      </header>

      {/* Navigation */}
      <nav className="bg-yellow-500">
        <div className="container mx-auto px-4">
          <div className="flex items-center justify-center">
            <div className="flex space-x-16">
              <Link href="/" className="flex items-center py-3 text-black hover:text-gray-700">
                <div className="flex items-center">
                  <Home className="h-5 w-5 mr-2" />
                  <div className="flex flex-col">
                    <span className="font-semibold text-sm">ANASAYFA</span>
                    <span className="text-xs">Firma rehberi anasayfanız</span>
                  </div>
                </div>
              </Link>
              <Link href="/firmalar" className="flex items-center py-3 text-black hover:text-gray-700">
                <div className="flex items-center">
                  <Briefcase className="h-5 w-5 mr-2" />
                  <div className="flex flex-col">
                    <span className="font-semibold text-sm">FİRMALAR</span>
                    <span className="text-xs">Kayıtlı firmalar</span>
                  </div>
                </div>
              </Link>
              <Link
                href="/fuar-etkinlikler"
                className="flex items-center py-3 text-black hover:text-gray-700 bg-yellow-600 px-4 rounded"
              >
                <div className="flex items-center">
                  <Calendar className="h-5 w-5 mr-2" />
                  <div className="flex flex-col">
                    <span className="font-semibold text-sm">FUAR & ETKİNLİKLER</span>
                    <span className="text-xs">Yaklaşan fuar ve etkinlikler</span>
                  </div>
                </div>
              </Link>
            </div>
          </div>
        </div>
      </nav>

      {/* Breadcrumb */}
      <div className="bg-white border-b">
        <div className="container mx-auto px-4 py-3">
          <div className="flex items-center text-sm text-gray-600">
            <Link href="/" className="hover:text-yellow-600">
              Anasayfa
            </Link>
            <ChevronRight className="h-4 w-4 mx-2" />
            <span className="text-gray-900 font-medium">Fuar & Etkinlikler</span>
          </div>
        </div>
      </div>

      {/* Hero Section */}
      <section className="bg-gradient-to-r from-purple-600 to-blue-600 text-white py-16">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-4xl md:text-5xl font-bold mb-4">FUAR & ETKİNLİKLER</h2>
          <p className="text-xl mb-8">
            İzmir'deki tüm fuar, konferans ve etkinlikleri keşfedin. Networking fırsatlarını kaçırmayın!
          </p>
          <div className="max-w-2xl mx-auto bg-white rounded-lg p-2 flex flex-col md:flex-row gap-2">
            <div className="flex-1 relative">
              <Search className="absolute left-3 top-3 h-5 w-5 text-gray-400" />
              <Input
                placeholder="Etkinlik ara..."
                className="pl-10 border-0 focus:ring-0 text-gray-900"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
            </div>
            <Button className="bg-purple-600 hover:bg-purple-700 text-white px-8 font-semibold">ARAMA YAP</Button>
          </div>
        </div>
      </section>

      {/* Main Content */}
      <div className="container mx-auto px-4 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
          {/* Sidebar - Filters */}
          <div className="lg:col-span-1">
            {/* Filters */}
            <Card className="mb-6">
              <div className="bg-purple-600 text-white p-4 flex items-center">
                <Filter className="h-5 w-5 mr-2" />
                <h2 className="font-bold text-lg">FİLTRELER</h2>
              </div>
              <div className="p-4 space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Kategori</label>
                  <Select value={selectedCategory} onValueChange={setSelectedCategory}>
                    <SelectTrigger>
                      <SelectValue placeholder="Kategori seçin" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">Tüm Kategoriler</SelectItem>
                      {categories.map((category) => (
                        <SelectItem key={category} value={category}>
                          {category}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Durum</label>
                  <Select value={filterBy} onValueChange={setFilterBy}>
                    <SelectTrigger>
                      <SelectValue placeholder="Durum seçin" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">Tüm Etkinlikler</SelectItem>
                      <SelectItem value="upcoming">Yaklaşan Etkinlikler</SelectItem>
                      <SelectItem value="featured">Öne Çıkan Etkinlikler</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Sıralama</label>
                  <Select value={sortBy} onValueChange={setSortBy}>
                    <SelectTrigger>
                      <SelectValue placeholder="Sıralama" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="date">Tarihe Göre</SelectItem>
                      <SelectItem value="title">İsme Göre (A-Z)</SelectItem>
                      <SelectItem value="category">Kategoriye Göre</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                {(selectedCategory !== "all" || searchTerm || filterBy !== "all") && (
                  <Button onClick={clearFilters} variant="outline" className="w-full bg-transparent">
                    Filtreleri Temizle
                  </Button>
                )}
              </div>
            </Card>

            {/* Statistics */}
            <Card>
              <div className="bg-green-600 text-white p-4 flex items-center">
                <Calendar className="h-5 w-5 mr-2" />
                <h2 className="font-bold text-lg">İSTATİSTİKLER</h2>
              </div>
              <div className="p-4">
                <div className="space-y-2 text-sm">
                  <div className="flex justify-between">
                    <span>Toplam Etkinlik:</span>
                    <span className="font-semibold">{events.length}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Filtrelenmiş:</span>
                    <span className="font-semibold text-blue-600">{filteredEvents.length}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Yaklaşan:</span>
                    <span className="font-semibold text-green-600">
                      {Array.isArray(events) ? events.filter((e) => e.isUpcoming).length : 0}
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span>Öne Çıkan:</span>
                    <span className="font-semibold text-purple-600">
                      {Array.isArray(events) ? events.filter((e) => e.isFeatured).length : 0}
                    </span>
                  </div>
                </div>
              </div>
            </Card>
          </div>

          {/* Events List */}
          <div className="lg:col-span-3">
            {/* Header */}
            <div className="flex items-center justify-between mb-6">
              <div>
                <h1 className="text-2xl font-bold text-gray-900 mb-2">FUAR & ETKİNLİKLER</h1>
                <p className="text-gray-600">
                  {filteredEvents.length} etkinlik listeleniyor
                  {selectedCategory !== "all" && (
                    <span className="text-purple-600 font-medium"> - {selectedCategory}</span>
                  )}
                </p>
              </div>
            </div>

            {/* Events */}
            {filteredEvents.length > 0 ? (
              <div className="space-y-6">
                {filteredEvents.map((event) => (
                  <Card key={event.id} className="hover:shadow-lg transition-shadow border overflow-hidden">
                    <div className="md:flex">
                      <div className="md:w-1/3">
                        <div
                          className="h-48 md:h-full bg-cover bg-center"
                          style={{ backgroundImage: `url('${event.image}')` }}
                        />
                      </div>
                      <div className="md:w-2/3">
                        <CardContent className="p-6">
                          <div className="flex items-start justify-between mb-3">
                            <div className="flex-1">
                              <div className="flex items-center space-x-2 mb-2">
                                <h3 className="text-xl font-bold text-gray-900">{event.title}</h3>
                                {event.isFeatured && (
                                  <Badge className="bg-purple-500 text-white text-xs">ÖNE ÇIKAN</Badge>
                                )}
                                {event.isUpcoming && (
                                  <Badge className="bg-green-500 text-white text-xs">YAKLAŞAN</Badge>
                                )}
                              </div>
                              <Badge variant="outline" className="text-xs mb-3">
                                {event.category}
                              </Badge>
                            </div>
                          </div>

                          <p className="text-gray-600 mb-4 line-clamp-2">{event.description}</p>

                          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                            <div className="space-y-2">
                              <div className="flex items-center text-sm text-gray-600">
                                <Calendar className="h-4 w-4 mr-2 text-purple-500" />
                                <span>
                                  {new Date(event.date).toLocaleDateString("tr-TR")}
                                  {event.endDate && ` - ${new Date(event.endDate).toLocaleDateString("tr-TR")}`}
                                </span>
                              </div>
                              <div className="flex items-center text-sm text-gray-600">
                                <Clock className="h-4 w-4 mr-2 text-purple-500" />
                                <span>{event.time}</span>
                              </div>
                              <div className="flex items-center text-sm text-gray-600">
                                <MapPin className="h-4 w-4 mr-2 text-purple-500" />
                                <span>{event.location}</span>
                              </div>
                            </div>
                            <div className="space-y-2">
                              <div className="flex items-center text-sm text-gray-600">
                                <Users className="h-4 w-4 mr-2 text-purple-500" />
                                <span>{event.organizer}</span>
                              </div>
                              {event.capacity && (
                                <div className="flex items-center text-sm text-gray-600">
                                  <Users className="h-4 w-4 mr-2 text-purple-500" />
                                  <span>Kapasite: {event.capacity.toLocaleString()} kişi</span>
                                </div>
                              )}
                              <div className="flex items-center text-sm text-gray-600">
                                <Star className="h-4 w-4 mr-2 text-purple-500" />
                                <span className="font-semibold text-green-600">{event.price}</span>
                              </div>
                            </div>
                          </div>

                          {/* Tags */}
                          <div className="flex flex-wrap gap-2 mb-4">
                            {event.tags &&
                              event.tags.map((tag, index) => (
                                <Badge key={index} variant="secondary" className="text-xs">
                                  {tag}
                                </Badge>
                              ))}
                          </div>

                          {/* Contact & Actions */}
                          <div className="flex items-center justify-between pt-4 border-t">
                            <div className="flex items-center space-x-4 text-sm text-gray-600">
                              {event.phone && (
                                <div className="flex items-center">
                                  <Phone className="h-4 w-4 mr-1" />
                                  <span>{event.phone}</span>
                                </div>
                              )}
                              {event.email && (
                                <div className="flex items-center">
                                  <Mail className="h-4 w-4 mr-1" />
                                  <span>{event.email}</span>
                                </div>
                              )}
                            </div>
                            <div className="flex space-x-2">
                              {event.website && (
                                <Button size="sm" variant="outline" asChild>
                                  <a href={event.website} target="_blank" rel="noopener noreferrer">
                                    <ExternalLink className="h-4 w-4 mr-1" />
                                    Web Sitesi
                                  </a>
                                </Button>
                              )}
                              <Button size="sm" className="bg-purple-600 hover:bg-purple-700">
                                Detaylar
                              </Button>
                            </div>
                          </div>
                        </CardContent>
                      </div>
                    </div>
                  </Card>
                ))}
              </div>
            ) : (
              <div className="text-center py-12">
                <div className="mb-4">
                  <Calendar className="h-16 w-16 text-gray-300 mx-auto mb-4" />
                  <h3 className="text-lg font-semibold text-gray-600 mb-2">Etkinlik Bulunamadı</h3>
                  <p className="text-gray-500 text-sm">
                    Arama kriterlerinize uygun etkinlik bulunamadı. Farklı filtreler deneyebilirsiniz.
                  </p>
                </div>
                <Button onClick={clearFilters} className="bg-purple-600 hover:bg-purple-700 text-white">
                  Filtreleri Temizle
                </Button>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Footer */}
      <footer className="bg-slate-800 text-white py-12">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            <div>
              <div className="flex items-center mb-4">
                <div className="w-8 h-8 bg-yellow-500 rounded flex items-center justify-center mr-2">
                  <span className="text-black font-bold">İ</span>
                </div>
                <span className="text-xl font-bold">
                  izmir<span className="text-yellow-500">rehber</span>
                </span>
              </div>
              <p className="text-gray-300 text-sm">
                İzmir'in en kapsamlı iş rehberi. Tüm sektörlerden firmaları keşfedin.
              </p>
            </div>
            <div>
              <h4 className="font-semibold mb-4">Hızlı Linkler</h4>
              <ul className="space-y-2 text-sm">
                <li>
                  <Link href="/" className="text-gray-300 hover:text-yellow-500">
                    Anasayfa
                  </Link>
                </li>
                <li>
                  <Link href="/firmalar" className="text-gray-300 hover:text-yellow-500">
                    Firmalar
                  </Link>
                </li>
                <li>
                  <Link href="/fuar-etkinlikler" className="text-gray-300 hover:text-yellow-500">
                    Fuar ve Etkinlikler
                  </Link>
                </li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold mb-4">Popüler Kategoriler</h4>
              <ul className="space-y-2 text-sm">
                <li>
                  <button
                    onClick={() => setSelectedCategory("Teknoloji")}
                    className="text-gray-300 hover:text-yellow-500 text-left"
                  >
                    Teknoloji Fuarları
                  </button>
                </li>
                <li>
                  <button
                    onClick={() => setSelectedCategory("İş Dünyası")}
                    className="text-gray-300 hover:text-yellow-500 text-left"
                  >
                    İş Dünyası Etkinlikleri
                  </button>
                </li>
                <li>
                  <button
                    onClick={() => setSelectedCategory("Kültür")}
                    className="text-gray-300 hover:text-yellow-500 text-left"
                  >
                    Sanat ve Kültür
                  </button>
                </li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold mb-4">İletişim</h4>
              <div className="space-y-2 text-sm text-gray-300">
                <p className="flex items-center">
                  <Phone className="h-4 w-4 mr-2" />
                  {siteSettings.phone}
                </p>
                <p className="flex items-center">
                  <Mail className="h-4 w-4 mr-2" />
                  {siteSettings.email}
                </p>
                <p className="text-gray-400">İzmir, Türkiye</p>
              </div>
            </div>
          </div>
          <div className="border-t border-gray-700 mt-8 pt-8 text-center text-sm text-gray-400">
            <p>&copy; 2024 İzmir Rehber. Tüm hakları saklıdır.</p>
          </div>
        </div>
      </footer>
    </div>
  )
}
