"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import {
  Search,
  Phone,
  Mail,
  Star,
  MapPin,
  ChevronRight,
  ChevronDown,
  GraduationCap,
  Heart,
  Wrench,
  Building2,
  Car,
  Utensils,
  Home,
  Briefcase,
  Calendar,
} from "lucide-react"
import Link from "next/link"

interface Company {
  id: number
  name: string
  category: string
  subcategory?: string
  description: string
  phone: string
  email: string
  address: string
  website?: string
  image: string
  rating: number
  reviews: number
  isGold: boolean
  isFeatured: boolean
  joinDate: string
}

interface Category {
  id: number
  name: string
  slug: string
  icon: string
  parentId?: number
  subcategories?: Category[]
  isActive: boolean
  order: number
}

interface SiteSettings {
  phone: string
  email: string
  heroImage: string
  logo: string
  siteName: string
}

export default function HomePage() {
  const [companies, setCompanies] = useState<Company[]>([])
  const [categories, setCategories] = useState<Category[]>([])
  const [expandedCategories, setExpandedCategories] = useState<number[]>([])
  const [selectedCategory, setSelectedCategory] = useState<string>("")
  const [selectedSubcategory, setSelectedSubcategory] = useState<string>("")
  const [siteSettings, setSiteSettings] = useState<SiteSettings>({
    phone: "0 850 303 81 08",
    email: "info@izmirrehber.com",
    heroImage: "",
    logo: "",
    siteName: "izmirrehber",
  })
  const [searchTerm, setSearchTerm] = useState("")
  const [selectedLocation, setSelectedLocation] = useState("")

  // Verileri yükle
  useEffect(() => {
    // Site ayarlarını yükle
    const savedSettings = localStorage.getItem("siteSettings")
    if (savedSettings) {
      setSiteSettings(JSON.parse(savedSettings))
    }

    // Şirketleri yükle
    const savedCompanies = localStorage.getItem("companies")
    if (savedCompanies) {
      setCompanies(JSON.parse(savedCompanies))
    } else {
      // Varsayılan şirketler
      const defaultCompanies: Company[] = [
        {
          id: 1,
          name: "Uraz Tesisat ve Çilingir",
          category: "HİZMET SEKTÖRÜ",
          subcategory: "Tesisat Hizmetleri",
          description: "Profesyonel tesisat ve çilingir hizmetleri",
          phone: "0232 123 45 67",
          email: "info@uraztesisat.com",
          address: "Konak, İzmir",
          image: "/placeholder.svg?height=100&width=100",
          rating: 4.8,
          reviews: 156,
          isGold: true,
          isFeatured: true,
          joinDate: "10 TEMMUZ 2025",
        },
        {
          id: 2,
          name: "DH Teknik Periyodik Kontrol",
          category: "HİZMET SEKTÖRÜ",
          subcategory: "Teknik Servis",
          description: "Teknik kontrol ve periyodik muayene hizmetleri",
          phone: "0232 987 65 43",
          email: "info@dhteknik.com",
          address: "Bornova, İzmir",
          image: "/placeholder.svg?height=100&width=100",
          rating: 4.6,
          reviews: 89,
          isGold: true,
          isFeatured: true,
          joinDate: "23 HAZİRAN 2025",
        },
        {
          id: 3,
          name: "Karşıyaka Halı Yıkama",
          category: "HİZMET SEKTÖRÜ",
          subcategory: "Temizlik Hizmetleri",
          description: "Profesyonel halı yıkama ve temizlik hizmetleri",
          phone: "0232 456 78 90",
          email: "info@karsiyakahaliyikama.com",
          address: "Karşıyaka, İzmir",
          image: "/placeholder.svg?height=100&width=100",
          rating: 4.7,
          reviews: 234,
          isGold: true,
          isFeatured: true,
          joinDate: "27 KASIM 2019",
        },
        {
          id: 4,
          name: "İzmir Tasarım | Kurumsal Web Tasarım",
          category: "BİLGİSAYAR - ELEKTRONİK",
          subcategory: "Web Tasarım",
          description: "Kurumsal web tasarım ve dijital pazarlama hizmetleri",
          phone: "0232 321 54 87",
          email: "info@izmirtasarim.com",
          address: "Alsancak, İzmir",
          image: "/placeholder.svg?height=100&width=100",
          rating: 4.9,
          reviews: 167,
          isGold: true,
          isFeatured: true,
          joinDate: "3 ŞUBAT 2017",
        },
        {
          id: 5,
          name: "İzmir Devlet Hastanesi",
          category: "SAĞLIK HİZMETLERİ",
          subcategory: "Hastaneler",
          description: "Genel sağlık hizmetleri ve acil müdahale",
          phone: "0232 555 12 34",
          email: "info@izmirdevlet.gov.tr",
          address: "Konak, İzmir",
          image: "/placeholder.svg?height=100&width=100",
          rating: 4.2,
          reviews: 89,
          isGold: false,
          isFeatured: false,
          joinDate: "15 MART 2020",
        },
        {
          id: 6,
          name: "Ege Üniversitesi",
          category: "EĞİTİM",
          subcategory: "Üniversiteler",
          description: "Yükseköğretim ve araştırma faaliyetleri",
          phone: "0232 311 10 10",
          email: "info@ege.edu.tr",
          address: "Bornova, İzmir",
          image: "/placeholder.svg?height=100&width=100",
          rating: 4.5,
          reviews: 245,
          isGold: false,
          isFeatured: false,
          joinDate: "5 OCAK 2018",
        },
        {
          id: 7,
          name: "Ziraat Bankası Konak Şubesi",
          category: "BANKALAR VE FİNANSAL HİZMETLER",
          subcategory: "Bankalar",
          description: "Bankacılık ve finansal hizmetler",
          phone: "0232 444 00 00",
          email: "konak@ziraatbank.com.tr",
          address: "Konak, İzmir",
          image: "/placeholder.svg?height=100&width=100",
          rating: 4.1,
          reviews: 67,
          isGold: false,
          isFeatured: false,
          joinDate: "12 MAYIS 2019",
        },
        {
          id: 8,
          name: "Kordon Otel",
          category: "TURİZM VE OTEL",
          subcategory: "Oteller",
          description: "Deniz manzaralı konforlu konaklama",
          phone: "0232 489 10 00",
          email: "info@kordonotel.com",
          address: "Alsancak, İzmir",
          image: "/placeholder.svg?height=100&width=100",
          rating: 4.6,
          reviews: 189,
          isGold: true,
          isFeatured: true,
          joinDate: "8 AĞUSTOS 2020",
        },
        {
          id: 9,
          name: "Akbank Alsancak Şubesi",
          category: "BANKALAR VE FİNANSAL HİZMETLER",
          subcategory: "Bankalar",
          description: "Modern bankacılık hizmetleri",
          phone: "0232 464 20 00",
          email: "alsancak@akbank.com",
          address: "Alsancak, İzmir",
          image: "/placeholder.svg?height=100&width=100",
          rating: 4.3,
          reviews: 124,
          isGold: false,
          isFeatured: false,
          joinDate: "18 EYLÜL 2018",
        },
        {
          id: 10,
          name: "Axa Sigorta İzmir",
          category: "BANKALAR VE FİNANSAL HİZMETLER",
          subcategory: "Sigorta Şirketleri",
          description: "Kapsamlı sigorta çözümleri",
          phone: "0232 421 30 00",
          email: "izmir@axasigorta.com.tr",
          address: "Konak, İzmir",
          image: "/placeholder.svg?height=100&width=100",
          rating: 4.0,
          reviews: 78,
          isGold: false,
          isFeatured: false,
          joinDate: "5 NİSAN 2019",
        },
        {
          id: 11,
          name: "Bilgisayar Dünyası",
          category: "BİLGİSAYAR - ELEKTRONİK",
          subcategory: "Bilgisayar Satış ve Servis",
          description: "Bilgisayar satış ve teknik servis hizmetleri",
          phone: "0232 445 67 89",
          email: "info@bilgisayardunyasi.com",
          address: "Bornova, İzmir",
          image: "/placeholder.svg?height=100&width=100",
          rating: 4.4,
          reviews: 156,
          isGold: false,
          isFeatured: false,
          joinDate: "12 OCAK 2020",
        },
        {
          id: 12,
          name: "Özel Sağlık Polikliniği",
          category: "SAĞLIK HİZMETLERİ",
          subcategory: "Özel Klinikler",
          description: "Uzman doktor kadrosu ile sağlık hizmetleri",
          phone: "0232 234 56 78",
          email: "info@ozelsaglik.com",
          address: "Karşıyaka, İzmir",
          image: "/placeholder.svg?height=100&width=100",
          rating: 4.7,
          reviews: 203,
          isGold: true,
          isFeatured: false,
          joinDate: "8 MART 2019",
        },
      ]
      setCompanies(defaultCompanies)
      localStorage.setItem("companies", JSON.stringify(defaultCompanies))
    }

    // Kategorileri yükle
    const savedCategories = localStorage.getItem("categories")
    if (savedCategories) {
      setCategories(JSON.parse(savedCategories))
    } else {
      // Kapsamlı kategoriler ve alt kategoriler
      const defaultCategories: Category[] = [
        // BANKALAR VE FİNANSAL HİZMETLER
        {
          id: 1,
          name: "BANKALAR VE FİNANSAL HİZMETLER",
          slug: "bankalar-ve-finansal-hizmetler",
          icon: "Building2",
          isActive: true,
          order: 1,
        },
        {
          id: 11,
          name: "Bankalar",
          slug: "bankalar",
          icon: "Building2",
          parentId: 1,
          isActive: true,
          order: 1,
        },
        {
          id: 12,
          name: "Sigorta Şirketleri",
          slug: "sigorta-sirketleri",
          icon: "Building2",
          parentId: 1,
          isActive: true,
          order: 2,
        },
        {
          id: 13,
          name: "Finansal Danışmanlık",
          slug: "finansal-danismanlik",
          icon: "Building2",
          parentId: 1,
          isActive: true,
          order: 3,
        },
        {
          id: 14,
          name: "Kredi Kuruluşları",
          slug: "kredi-kuruluslari",
          icon: "Building2",
          parentId: 1,
          isActive: true,
          order: 4,
        },
        {
          id: 15,
          name: "Yatırım Danışmanlığı",
          slug: "yatirim-danismanligi",
          icon: "Building2",
          parentId: 1,
          isActive: true,
          order: 5,
        },

        // BİLGİSAYAR - ELEKTRONİK
        {
          id: 2,
          name: "BİLGİSAYAR - ELEKTRONİK",
          slug: "bilgisayar-elektronik",
          icon: "Monitor",
          isActive: true,
          order: 2,
        },
        {
          id: 21,
          name: "Bilgisayar Satış ve Servis",
          slug: "bilgisayar-satis-servis",
          icon: "Monitor",
          parentId: 2,
          isActive: true,
          order: 1,
        },
        {
          id: 22,
          name: "Web Tasarım",
          slug: "web-tasarim",
          icon: "Monitor",
          parentId: 2,
          isActive: true,
          order: 2,
        },
        {
          id: 23,
          name: "Yazılım Geliştirme",
          slug: "yazilim-gelistirme",
          icon: "Monitor",
          parentId: 2,
          isActive: true,
          order: 3,
        },
        {
          id: 24,
          name: "Elektronik Eşya",
          slug: "elektronik-esya",
          icon: "Monitor",
          parentId: 2,
          isActive: true,
          order: 4,
        },
        {
          id: 25,
          name: "Bilişim Danışmanlığı",
          slug: "bilisim-danismanligi",
          icon: "Monitor",
          parentId: 2,
          isActive: true,
          order: 5,
        },
        {
          id: 26,
          name: "Mobil Uygulama",
          slug: "mobil-uygulama",
          icon: "Monitor",
          parentId: 2,
          isActive: true,
          order: 6,
        },

        // HİZMET SEKTÖRÜ
        {
          id: 3,
          name: "HİZMET SEKTÖRÜ",
          slug: "hizmet-sektoru",
          icon: "Wrench",
          isActive: true,
          order: 3,
        },
        {
          id: 31,
          name: "Temizlik Hizmetleri",
          slug: "temizlik-hizmetleri",
          icon: "Wrench",
          parentId: 3,
          isActive: true,
          order: 1,
        },
        {
          id: 32,
          name: "Tesisat Hizmetleri",
          slug: "tesisat-hizmetleri",
          icon: "Wrench",
          parentId: 3,
          isActive: true,
          order: 2,
        },
        {
          id: 33,
          name: "Elektrik Hizmetleri",
          slug: "elektrik-hizmetleri",
          icon: "Wrench",
          parentId: 3,
          isActive: true,
          order: 3,
        },
        {
          id: 34,
          name: "Güvenlik Hizmetleri",
          slug: "guvenlik-hizmetleri",
          icon: "Wrench",
          parentId: 3,
          isActive: true,
          order: 4,
        },
        {
          id: 35,
          name: "Nakliye ve Taşımacılık",
          slug: "nakliye-ve-tasimacilik",
          icon: "Wrench",
          parentId: 3,
          isActive: true,
          order: 5,
        },
        {
          id: 36,
          name: "Teknik Servis",
          slug: "teknik-servis",
          icon: "Wrench",
          parentId: 3,
          isActive: true,
          order: 6,
        },
        {
          id: 37,
          name: "Bahçıvanlık",
          slug: "bahcivanlik",
          icon: "Wrench",
          parentId: 3,
          isActive: true,
          order: 7,
        },
        {
          id: 38,
          name: "Boyacılık",
          slug: "boyacilik",
          icon: "Wrench",
          parentId: 3,
          isActive: true,
          order: 8,
        },
        {
          id: 39,
          name: "Çilingir Hizmetleri",
          slug: "cilingir-hizmetleri",
          icon: "Wrench",
          parentId: 3,
          isActive: true,
          order: 9,
        },

        // İNŞAAT VE YAPI
        {
          id: 4,
          name: "İNŞAAT VE YAPI",
          slug: "insaat-ve-yapi",
          icon: "Building2",
          isActive: true,
          order: 4,
        },
        {
          id: 41,
          name: "İnşaat Firmaları",
          slug: "insaat-firmalari",
          icon: "Building2",
          parentId: 4,
          isActive: true,
          order: 1,
        },
        {
          id: 42,
          name: "Mimarlık Büroları",
          slug: "mimarlik-burolari",
          icon: "Building2",
          parentId: 4,
          isActive: true,
          order: 2,
        },
        {
          id: 43,
          name: "İç Mimarlık",
          slug: "ic-mimarlik",
          icon: "Building2",
          parentId: 4,
          isActive: true,
          order: 3,
        },
        {
          id: 44,
          name: "Yapı Malzemeleri",
          slug: "yapi-malzemeleri",
          icon: "Building2",
          parentId: 4,
          isActive: true,
          order: 4,
        },
        {
          id: 45,
          name: "Peyzaj Mimarlığı",
          slug: "peyzaj-mimarligi",
          icon: "Building2",
          parentId: 4,
          isActive: true,
          order: 5,
        },
        {
          id: 46,
          name: "Müteahhitlik",
          slug: "muteahhitlik",
          icon: "Building2",
          parentId: 4,
          isActive: true,
          order: 6,
        },

        // SAĞLIK HİZMETLERİ
        {
          id: 5,
          name: "SAĞLIK HİZMETLERİ",
          slug: "saglik-hizmetleri",
          icon: "Heart",
          isActive: true,
          order: 5,
        },
        {
          id: 51,
          name: "Hastaneler",
          slug: "hastaneler",
          icon: "Heart",
          parentId: 5,
          isActive: true,
          order: 1,
        },
        {
          id: 52,
          name: "Özel Klinikler",
          slug: "ozel-klinikler",
          icon: "Heart",
          parentId: 5,
          isActive: true,
          order: 2,
        },
        {
          id: 53,
          name: "Diş Hekimleri",
          slug: "dis-hekimleri",
          icon: "Heart",
          parentId: 5,
          isActive: true,
          order: 3,
        },
        {
          id: 54,
          name: "Eczaneler",
          slug: "eczaneler",
          icon: "Heart",
          parentId: 5,
          isActive: true,
          order: 4,
        },
        {
          id: 55,
          name: "Veteriner Hekimler",
          slug: "veteriner-hekimler",
          icon: "Heart",
          parentId: 5,
          isActive: true,
          order: 5,
        },
        {
          id: 56,
          name: "Optisyenler",
          slug: "optisyenler",
          icon: "Heart",
          parentId: 5,
          isActive: true,
          order: 6,
        },

        // EĞİTİM
        {
          id: 6,
          name: "EĞİTİM",
          slug: "egitim",
          icon: "GraduationCap",
          isActive: true,
          order: 6,
        },
        {
          id: 61,
          name: "Okullar",
          slug: "okullar",
          icon: "GraduationCap",
          parentId: 6,
          isActive: true,
          order: 1,
        },
        {
          id: 62,
          name: "Üniversiteler",
          slug: "universiteler",
          icon: "GraduationCap",
          parentId: 6,
          isActive: true,
          order: 2,
        },
        {
          id: 63,
          name: "Dershaneler",
          slug: "dershaneler",
          icon: "GraduationCap",
          parentId: 6,
          isActive: true,
          order: 3,
        },
        {
          id: 64,
          name: "Dil Kursları",
          slug: "dil-kurslari",
          icon: "GraduationCap",
          parentId: 6,
          isActive: true,
          order: 4,
        },
        {
          id: 65,
          name: "Meslek Kursları",
          slug: "meslek-kurslari",
          icon: "GraduationCap",
          parentId: 6,
          isActive: true,
          order: 5,
        },
        {
          id: 66,
          name: "Anaokulu",
          slug: "anaokulu",
          icon: "GraduationCap",
          parentId: 6,
          isActive: true,
          order: 6,
        },

        // TURİZM VE OTEL
        {
          id: 7,
          name: "TURİZM VE OTEL",
          slug: "turizm-ve-otel",
          icon: "Car",
          isActive: true,
          order: 7,
        },
        {
          id: 71,
          name: "Oteller",
          slug: "oteller",
          icon: "Car",
          parentId: 7,
          isActive: true,
          order: 1,
        },
        {
          id: 72,
          name: "Seyahat Acenteleri",
          slug: "seyahat-acenteleri",
          icon: "Car",
          parentId: 7,
          isActive: true,
          order: 2,
        },
        {
          id: 73,
          name: "Tur Operatörleri",
          slug: "tur-operatorleri",
          icon: "Car",
          parentId: 7,
          isActive: true,
          order: 3,
        },
        {
          id: 74,
          name: "Araç Kiralama",
          slug: "arac-kiralama",
          icon: "Car",
          parentId: 7,
          isActive: true,
          order: 4,
        },
        {
          id: 75,
          name: "Rehberlik Hizmetleri",
          slug: "rehberlik-hizmetleri",
          icon: "Car",
          parentId: 7,
          isActive: true,
          order: 5,
        },

        // YEME İÇME
        {
          id: 8,
          name: "YEME İÇME",
          slug: "yeme-icme",
          icon: "Utensils",
          isActive: true,
          order: 8,
        },
        {
          id: 81,
          name: "Restoranlar",
          slug: "restoranlar",
          icon: "Utensils",
          parentId: 8,
          isActive: true,
          order: 1,
        },
        {
          id: 82,
          name: "Kafeler",
          slug: "kafeler",
          icon: "Utensils",
          parentId: 8,
          isActive: true,
          order: 2,
        },
        {
          id: 83,
          name: "Fast Food",
          slug: "fast-food",
          icon: "Utensils",
          parentId: 8,
          isActive: true,
          order: 3,
        },
        {
          id: 84,
          name: "Pastaneler",
          slug: "pastaneler",
          icon: "Utensils",
          parentId: 8,
          isActive: true,
          order: 4,
        },
        {
          id: 85,
          name: "Catering",
          slug: "catering",
          icon: "Utensils",
          parentId: 8,
          isActive: true,
          order: 5,
        },

        // OTOMOTİV
        {
          id: 9,
          name: "OTOMOTİV",
          slug: "otomotiv",
          icon: "Car",
          isActive: true,
          order: 9,
        },
        {
          id: 91,
          name: "Otomobil Bayileri",
          slug: "otomobil-bayileri",
          icon: "Car",
          parentId: 9,
          isActive: true,
          order: 1,
        },
        {
          id: 92,
          name: "Oto Servis",
          slug: "oto-servis",
          icon: "Car",
          parentId: 9,
          isActive: true,
          order: 2,
        },
        {
          id: 93,
          name: "Yedek Parça",
          slug: "yedek-parca",
          icon: "Car",
          parentId: 9,
          isActive: true,
          order: 3,
        },
        {
          id: 94,
          name: "Oto Ekspertiz",
          slug: "oto-ekspertiz",
          icon: "Car",
          parentId: 9,
          isActive: true,
          order: 4,
        },
        {
          id: 95,
          name: "Lastik Servisi",
          slug: "lastik-servisi",
          icon: "Car",
          parentId: 9,
          isActive: true,
          order: 5,
        },

        // EMLAK
        {
          id: 10,
          name: "EMLAK",
          slug: "emlak",
          icon: "Home",
          isActive: true,
          order: 10,
        },
        {
          id: 101,
          name: "Emlak Ofisleri",
          slug: "emlak-ofisleri",
          icon: "Home",
          parentId: 10,
          isActive: true,
          order: 1,
        },
        {
          id: 102,
          name: "Gayrimenkul Danışmanlığı",
          slug: "gayrimenkul-danismanligi",
          icon: "Home",
          parentId: 10,
          isActive: true,
          order: 2,
        },
        {
          id: 103,
          name: "Emlak Değerleme",
          slug: "emlak-degerleme",
          icon: "Home",
          parentId: 10,
          isActive: true,
          order: 3,
        },
        {
          id: 104,
          name: "Konut Projeleri",
          slug: "konut-projeleri",
          icon: "Home",
          parentId: 10,
          isActive: true,
          order: 4,
        },
      ]
      setCategories(defaultCategories)
      localStorage.setItem("categories", JSON.stringify(defaultCategories))
    }
  }, [])

  // Ana kategorileri al
  const getMainCategories = () => {
    return categories.filter((cat) => !cat.parentId && cat.isActive).sort((a, b) => a.order - b.order)
  }

  // Alt kategorileri al
  const getSubCategories = (parentId: number) => {
    return categories.filter((cat) => cat.parentId === parentId && cat.isActive).sort((a, b) => a.order - b.order)
  }

  // Kategori genişletme/daraltma
  const toggleCategory = (categoryId: number) => {
    setExpandedCategories((prev) =>
      prev.includes(categoryId) ? prev.filter((id) => id !== categoryId) : [...prev, categoryId],
    )
  }

  // Kategori filtreleme
  const handleCategoryFilter = (categoryName: string) => {
    setSelectedCategory(categoryName)
    setSelectedSubcategory("")
  }

  // Alt kategori filtreleme
  const handleSubcategoryFilter = (subcategoryName: string) => {
    setSelectedSubcategory(subcategoryName)
  }

  // Filtreleri temizle
  const clearFilters = () => {
    setSelectedCategory("")
    setSelectedSubcategory("")
    setSearchTerm("")
  }

  // Filtrelenmiş şirketler
  const getFilteredCompanies = () => {
    let filtered = companies

    // Kategori filtresi
    if (selectedCategory) {
      filtered = filtered.filter((company) => company.category === selectedCategory)
    }

    // Alt kategori filtresi
    if (selectedSubcategory) {
      filtered = filtered.filter((company) => company.subcategory === selectedSubcategory)
    }

    // Arama filtresi
    if (searchTerm) {
      filtered = filtered.filter(
        (company) =>
          company.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
          company.description.toLowerCase().includes(searchTerm.toLowerCase()),
      )
    }

    return filtered
  }

  // Vitrin firmaları
  const featuredCompanies = companies.filter((company) => company.isFeatured)

  // Kategori ikonları - dinamik firma sayıları ile
  const categoryIcons = [
    {
      icon: GraduationCap,
      name: "EĞİTİM",
      count: `${companies.filter((c) => c.category === "EĞİTİM").length} FİRMA`,
      slug: "egitim",
    },
    {
      icon: Wrench,
      name: "HİZMET SEKTÖRÜ",
      count: `${companies.filter((c) => c.category === "HİZMET SEKTÖRÜ").length} FİRMA`,
      slug: "hizmet-sektoru",
    },
    {
      icon: Phone,
      name: "İLETİŞİM",
      count: `${companies.filter((c) => c.category === "İLETİŞİM").length} FİRMA`,
      slug: "iletisim",
    },
    {
      icon: Building2,
      name: "İNŞAAT VE YAPI",
      count: `${companies.filter((c) => c.category === "İNŞAAT VE YAPI").length} FİRMA`,
      slug: "insaat-ve-yapi",
    },
    {
      icon: Heart,
      name: "SAĞLIK HİZMETLERİ",
      count: `${companies.filter((c) => c.category === "SAĞLIK HİZMETLERİ").length} FİRMA`,
      slug: "saglik-hizmetleri",
    },
    {
      icon: Car,
      name: "TURİZM VE OTEL",
      count: `${companies.filter((c) => c.category === "TURİZM VE OTEL").length} FİRMA`,
      slug: "turizm-ve-otel",
    },
    {
      icon: Utensils,
      name: "YEME İÇME",
      count: `${companies.filter((c) => c.category === "YEME İÇME").length} FİRMA`,
      slug: "yeme-icme",
    },
  ]

  const filteredCompanies = getFilteredCompanies()

  return (
    <div className="min-h-screen bg-gray-100">
      {/* Top Header */}
      <div className="bg-white border-b">
        <div className="container mx-auto px-4 py-2">
          <div className="flex justify-between items-center text-sm">
            <div className="flex items-center space-x-6">
              <div className="flex items-center text-gray-600">
                <Mail className="h-4 w-4 mr-1" />
                {siteSettings.email}
              </div>
              <div className="flex items-center text-gray-600">
                <Phone className="h-4 w-4 mr-1" />
                {siteSettings.phone}
              </div>
            </div>
            <div className="flex items-center space-x-4">
              <div className="flex space-x-2">
                {/* Social Media Icons */}
                <div className="w-6 h-6 bg-blue-600 rounded-full flex items-center justify-center">
                  <span className="text-white text-xs">f</span>
                </div>
                <div className="w-6 h-6 bg-blue-400 rounded-full flex items-center justify-center">
                  <span className="text-white text-xs">t</span>
                </div>
                <div className="w-6 h-6 bg-red-600 rounded-full flex items-center justify-center">
                  <span className="text-white text-xs">g</span>
                </div>
                <div className="w-6 h-6 bg-blue-700 rounded-full flex items-center justify-center">
                  <span className="text-white text-xs">in</span>
                </div>
                <div className="w-6 h-6 bg-red-500 rounded-full flex items-center justify-center">
                  <span className="text-white text-xs">y</span>
                </div>
                <div className="w-6 h-6 bg-green-600 rounded-full flex items-center justify-center">
                  <span className="text-white text-xs">w</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Main Header */}
      <header className="bg-white shadow-sm">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-center">
            <div className="flex items-center">
              <div className="w-12 h-12 bg-yellow-500 rounded-lg flex items-center justify-center mr-3">
                <span className="text-white font-bold text-xl">İ</span>
              </div>
              <div>
                <h1 className="text-2xl font-bold text-gray-900">
                  izmir<span className="text-yellow-500">rehber</span>
                </h1>
              </div>
            </div>
          </div>
        </div>
      </header>

      {/* Navigation */}
      <nav className="bg-yellow-500">
        <div className="container mx-auto px-4">
          <div className="flex items-center justify-center">
            <div className="flex space-x-16">
              <Link href="/" className="flex items-center py-3 text-black hover:text-gray-700">
                <div className="flex items-center">
                  <Home className="h-5 w-5 mr-2" />
                  <div className="flex flex-col">
                    <span className="font-semibold text-sm">ANASAYFA</span>
                    <span className="text-xs">Firma rehberi anasayfanız</span>
                  </div>
                </div>
              </Link>
              <Link href="/firmalar" className="flex items-center py-3 text-black hover:text-gray-700">
                <div className="flex items-center">
                  <Briefcase className="h-5 w-5 mr-2" />
                  <div className="flex flex-col">
                    <span className="font-semibold text-sm">FİRMALAR</span>
                    <span className="text-xs">Kayıtlı firmalar</span>
                  </div>
                </div>
              </Link>
              <Link href="/fuar-etkinlikler" className="flex items-center py-3 text-black hover:text-gray-700">
                <div className="flex items-center">
                  <Calendar className="h-5 w-5 mr-2" />
                  <div className="flex flex-col">
                    <span className="font-semibold text-sm">FUAR & ETKİNLİKLER</span>
                    <span className="text-xs">Yaklaşan fuar ve etkinlikler</span>
                  </div>
                </div>
              </Link>
            </div>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section
        className="relative bg-cover bg-center py-24"
        style={{
          backgroundImage: `linear-gradient(rgba(0,0,0,0.4), rgba(0,0,0,0.4)), url('/images/izmir-hero-bg.jpg')`,
        }}
      >
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-4xl md:text-5xl font-bold text-white mb-4">NASIL YARDIMCI OLABİLİRİZ?</h2>
          <p className="text-xl text-white mb-8">
            Bulunduğunuz bölgede yer alan firmaların haberlerini, ilanlarını ve ürünlerini listeleyelin...
          </p>

          {/* Search Form */}
          <div className="max-w-4xl mx-auto bg-white rounded-lg p-2 flex flex-col md:flex-row gap-2">
            <div className="flex-1 relative">
              <Search className="absolute left-3 top-3 h-5 w-5 text-gray-400" />
              <Input
                placeholder="Firma adı veya hizmet ara..."
                className="pl-10 border-0 focus:ring-0"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
            </div>
            <div className="flex-1 relative">
              <MapPin className="absolute left-3 top-3 h-5 w-5 text-gray-400" />
              <Input
                placeholder="Aramak istediğiniz bölgeyi seçiniz..."
                className="pl-10 border-0 focus:ring-0"
                value={selectedLocation}
                onChange={(e) => setSelectedLocation(e.target.value)}
              />
            </div>
            <Button className="bg-yellow-500 hover:bg-yellow-600 text-black px-8 font-semibold">ARAMA YAP</Button>
          </div>
        </div>
      </section>

      {/* Category Icons */}
      <section className="py-0">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-7 -mt-12 relative z-10 gap-1">
            {categoryIcons.map((category, index) => (
              <button
                key={index}
                onClick={() =>
                  handleCategoryFilter(
                    category.name === "HİZMET"
                      ? "HİZMET SEKTÖRÜ"
                      : category.name === "İNŞAAT"
                        ? "İNŞAAT VE YAPI"
                        : category.name === "SAĞLIK"
                          ? "SAĞLIK HİZMETLERİ"
                          : category.name === "TURİZM"
                            ? "TURİZM VE OTEL"
                            : category.name === "YEME-İÇME"
                              ? "YEME İÇME"
                              : category.name,
                  )
                }
                className={`${
                  selectedCategory === category.name ? "bg-yellow-600" : "bg-slate-700 hover:bg-slate-600"
                } text-white transition-colors cursor-pointer rounded-lg`}
              >
                <Card className="bg-transparent border-0">
                  <CardContent className="p-4 text-center">
                    <category.icon className="h-8 w-8 mx-auto mb-2 text-white" />
                    <h3 className="font-semibold text-sm mb-1">{category.name}</h3>
                    <p className="text-xs text-gray-300">{category.count}</p>
                  </CardContent>
                </Card>
              </button>
            ))}
          </div>
        </div>
      </section>

      {/* Main Content */}
      <div className="container mx-auto px-4 py-12">
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
          {/* Sidebar - Categories */}
          <div className="lg:col-span-1">
            <Card className="mb-6">
              <div className="bg-slate-700 text-white p-4 flex items-center">
                <div className="w-6 h-6 bg-yellow-500 rounded mr-3 flex items-center justify-center">
                  <span className="text-black text-sm font-bold">≡</span>
                </div>
                <h2 className="font-bold text-lg">KATEGORİLER</h2>
              </div>
              <div className="bg-white">
                {/* Filtre temizleme butonu */}
                {(selectedCategory || selectedSubcategory || searchTerm) && (
                  <div className="p-3 border-b bg-yellow-50">
                    <Button onClick={clearFilters} size="sm" variant="outline" className="w-full text-xs bg-white">
                      Tüm Filtreleri Temizle
                    </Button>
                  </div>
                )}

                {getMainCategories().map((category) => {
                  const subCategories = getSubCategories(category.id)
                  const isExpanded = expandedCategories.includes(category.id)
                  const hasSubCategories = subCategories.length > 0
                  const isSelectedCategory = selectedCategory === category.name

                  return (
                    <div key={category.id} className="border-b border-gray-200 last:border-b-0">
                      <div
                        className={`flex items-center justify-between p-3 hover:bg-gray-50 transition-colors group ${
                          isSelectedCategory ? "bg-yellow-50 border-l-4 border-yellow-500" : ""
                        }`}
                      >
                        <button
                          onClick={() => handleCategoryFilter(category.name)}
                          className="flex items-center flex-1 text-left"
                        >
                          <div className="w-4 h-4 bg-gray-400 rounded-full mr-3"></div>
                          <span
                            className={`text-sm font-medium group-hover:text-yellow-600 ${
                              isSelectedCategory ? "text-yellow-600 font-semibold" : "text-gray-700"
                            }`}
                          >
                            {category.name}
                          </span>
                        </button>
                        <div className="flex items-center">
                          <span className="text-xs text-gray-500 mr-2">
                            ({companies.filter((c) => c.category === category.name).length})
                          </span>
                          {hasSubCategories && (
                            <button
                              onClick={() => toggleCategory(category.id)}
                              className="p-1 hover:bg-gray-100 rounded"
                            >
                              {isExpanded ? (
                                <ChevronDown className="h-4 w-4 text-gray-400" />
                              ) : (
                                <ChevronRight className="h-4 w-4 text-gray-400" />
                              )}
                            </button>
                          )}
                        </div>
                      </div>

                      {/* Alt Kategoriler */}
                      {hasSubCategories && isExpanded && (
                        <div className="bg-gray-50 border-t">
                          {subCategories.map((subCategory) => {
                            const isSelectedSubcategory = selectedSubcategory === subCategory.name
                            return (
                              <button
                                key={subCategory.id}
                                onClick={() => handleSubcategoryFilter(subCategory.name)}
                                className={`w-full flex items-center justify-between p-3 pl-8 hover:bg-gray-100 transition-colors group text-left ${
                                  isSelectedSubcategory ? "bg-yellow-100 border-l-4 border-yellow-500" : ""
                                }`}
                              >
                                <div className="flex items-center">
                                  <div className="w-3 h-3 bg-gray-300 rounded-full mr-3"></div>
                                  <span
                                    className={`text-sm group-hover:text-yellow-600 ${
                                      isSelectedSubcategory ? "text-yellow-600 font-semibold" : "text-gray-600"
                                    }`}
                                  >
                                    {subCategory.name}
                                  </span>
                                </div>
                                <div className="flex items-center">
                                  <span className="text-xs text-gray-400 mr-2">
                                    ({companies.filter((c) => c.subcategory === subCategory.name).length})
                                  </span>
                                  <ChevronRight className="h-3 w-3 text-gray-300 group-hover:text-yellow-500" />
                                </div>
                              </button>
                            )
                          })}
                        </div>
                      )}
                    </div>
                  )
                })}
              </div>
            </Card>

            {/* Admin Panel Link */}
            <Card>
              <CardContent className="p-4 text-center">
                <Link href="/admin">
                  <Button className="w-full bg-yellow-500 hover:bg-yellow-600 text-black font-semibold">
                    Admin Paneli
                  </Button>
                </Link>
              </CardContent>
            </Card>
          </div>

          {/* Companies List */}
          <div className="lg:col-span-3">
            {/* Filtrelenmiş Sonuçlar veya Vitrin Firmaları */}
            {selectedCategory || selectedSubcategory || searchTerm ? (
              <Card>
                <div className="bg-blue-600 text-white p-4 flex items-center">
                  <div className="w-6 h-6 bg-white rounded mr-3 flex items-center justify-center">
                    <Search className="h-4 w-4 text-blue-600" />
                  </div>
                  <h2 className="font-bold text-lg">ARAMA SONUÇLARI ({filteredCompanies.length} sonuç)</h2>
                </div>
                <div className="p-6 bg-white">
                  {filteredCompanies.length > 0 ? (
                    <div className="space-y-6">
                      {filteredCompanies.map((company) => (
                        <Card key={company.id} className="hover:shadow-lg transition-shadow border">
                          <CardContent className="p-6">
                            <div className="flex items-start space-x-4">
                              <div className="w-20 h-20 bg-gray-100 rounded-lg flex items-center justify-center flex-shrink-0">
                                <Building2 className="h-10 w-10 text-gray-400" />
                              </div>
                              <div className="flex-1">
                                <div className="flex items-center space-x-2 mb-2">
                                  <h4 className="font-semibold text-lg">{company.name}</h4>
                                  {company.isGold && (
                                    <Badge className="bg-yellow-500 text-black text-xs px-2 py-1">GOLD FİRMA</Badge>
                                  )}
                                  {company.isFeatured && (
                                    <Badge className="bg-blue-500 text-white text-xs ml-1">VİTRİN</Badge>
                                  )}
                                </div>
                                <p className="text-sm text-gray-600 mb-1">{company.category}</p>
                                {company.subcategory && (
                                  <p className="text-xs text-gray-500 mb-2">• {company.subcategory}</p>
                                )}
                                <p className="text-sm text-gray-500 mb-4">{company.description}</p>

                                <div className="grid grid-cols-1 md:grid-cols-3 gap-3 text-sm text-gray-600 mb-4">
                                  <div className="flex items-center">
                                    <Phone className="h-4 w-4 mr-2 text-gray-400" />
                                    {company.phone}
                                  </div>
                                  <div className="flex items-center">
                                    <Mail className="h-4 w-4 mr-2 text-gray-400" />
                                    {company.email}
                                  </div>
                                  <div className="flex items-center">
                                    <MapPin className="h-4 w-4 mr-2 text-gray-400" />
                                    {company.address}
                                  </div>
                                </div>

                                <div className="flex items-center justify-between">
                                  <div className="flex items-center">
                                    <Star className="h-4 w-4 text-yellow-400 fill-current" />
                                    <span className="text-sm ml-1 font-medium">{company.rating}</span>
                                    <span className="text-xs text-gray-500 ml-1">
                                      ({company.reviews} değerlendirme)
                                    </span>
                                  </div>
                                  <span className="text-xs text-gray-500">{company.joinDate} tarihinde katıldı</span>
                                </div>
                              </div>
                            </div>
                          </CardContent>
                        </Card>
                      ))}
                    </div>
                  ) : (
                    <div className="text-center py-12">
                      <div className="mb-4">
                        <Search className="h-16 w-16 text-gray-300 mx-auto mb-4" />
                        <h3 className="text-lg font-semibold text-gray-600 mb-2">Sonuç Bulunamadı</h3>
                        <p className="text-gray-500 text-sm">
                          Arama kriterlerinize uygun firma bulunamadı. Farklı anahtar kelimeler deneyebilirsiniz.
                        </p>
                      </div>
                      <Button onClick={clearFilters} className="bg-yellow-500 hover:bg-yellow-600 text-black">
                        Filtreleri Temizle
                      </Button>
                    </div>
                  )}
                </div>
              </Card>
            ) : (
              <Card>
                <div className="bg-yellow-500 text-black p-4 flex items-center">
                  <div className="w-6 h-6 bg-black rounded mr-3 flex items-center justify-center">
                    <Building2 className="h-4 w-4 text-yellow-500" />
                  </div>
                  <h2 className="font-bold text-lg">VİTRİNDEKİ FİRMALAR</h2>
                  <div className="ml-auto flex space-x-2">
                    <Button size="sm" variant="outline" className="bg-yellow-400 border-yellow-600 text-black">
                      ‹
                    </Button>
                    <Button size="sm" variant="outline" className="bg-yellow-400 border-yellow-600 text-black">
                      ›
                    </Button>
                  </div>
                </div>
                <div className="p-6 bg-white">
                  {featuredCompanies.length > 0 ? (
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                      {featuredCompanies.map((company) => (
                        <Card key={company.id} className="hover:shadow-lg transition-shadow border">
                          <CardContent className="p-4 text-center">
                            <div className="relative mb-3">
                              <Badge className="absolute -top-2 -right-2 bg-yellow-500 text-black text-xs px-2 py-1 rounded-full">
                                GOLD FİRMA
                              </Badge>
                              <div className="w-20 h-20 mx-auto bg-gray-100 rounded-lg flex items-center justify-center">
                                <Building2 className="h-10 w-10 text-gray-400" />
                              </div>
                            </div>
                            <h3 className="font-semibold text-sm mb-1 text-gray-900">{company.name}</h3>
                            <p className="text-xs text-gray-600 mb-1">{company.category}</p>
                            {company.subcategory && (
                              <p className="text-xs text-gray-500 mb-2">• {company.subcategory}</p>
                            )}
                            <div className="flex items-center justify-center mb-2">
                              <Star className="h-4 w-4 text-yellow-400 fill-current" />
                              <span className="text-sm ml-1">{company.rating}</span>
                              <span className="text-xs text-gray-500 ml-1">({company.reviews})</span>
                            </div>
                            <p className="text-xs text-gray-500">{company.joinDate} TARİHİNDE KATILDI</p>
                          </CardContent>
                        </Card>
                      ))}
                    </div>
                  ) : (
                    <div className="text-center py-12">
                      <div className="mb-4">
                        <Building2 className="h-16 w-16 text-gray-300 mx-auto mb-4" />
                        <h3 className="text-lg font-semibold text-gray-600 mb-2">Henüz Firma Bulunmuyor</h3>
                        <p className="text-gray-500 text-sm">Yakında bu alanda firmaları görebileceksiniz.</p>
                      </div>
                    </div>
                  )}
                </div>
              </Card>
            )}
          </div>
        </div>
      </div>

      {/* Footer */}
      <footer className="bg-slate-800 text-white py-12">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            <div>
              <div className="flex items-center mb-4">
                <div className="w-8 h-8 bg-yellow-500 rounded flex items-center justify-center mr-2">
                  <span className="text-black font-bold">İ</span>
                </div>
                <span className="text-xl font-bold">
                  izmir<span className="text-yellow-500">rehber</span>
                </span>
              </div>
              <p className="text-gray-300 text-sm">
                İzmir'in en kapsamlı iş rehberi. Tüm sektörlerden firmaları keşfedin.
              </p>
            </div>
            <div>
              <h4 className="font-semibold mb-4">Hızlı Linkler</h4>
              <ul className="space-y-2 text-sm">
                <li>
                  <Link href="/" className="text-gray-300 hover:text-yellow-500">
                    Anasayfa
                  </Link>
                </li>
                <li>
                  <Link href="/firmalar" className="text-gray-300 hover:text-yellow-500">
                    Firmalar
                  </Link>
                </li>
                <li>
                  <Link href="/fuar-etkinlikler" className="text-gray-300 hover:text-yellow-500">
                    Fuar ve Etkinlikler
                  </Link>
                </li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold mb-4">Popüler Kategoriler</h4>
              <ul className="space-y-2 text-sm">
                <li>
                  <button
                    onClick={() => handleCategoryFilter("BİLGİSAYAR - ELEKTRONİK")}
                    className="text-gray-300 hover:text-yellow-500 text-left"
                  >
                    Bilgisayar - Elektronik
                  </button>
                </li>
                <li>
                  <button
                    onClick={() => handleCategoryFilter("HİZMET SEKTÖRÜ")}
                    className="text-gray-300 hover:text-yellow-500 text-left"
                  >
                    Hizmet Sektörü
                  </button>
                </li>
                <li>
                  <button
                    onClick={() => handleCategoryFilter("BANKALAR VE FİNANSAL HİZMETLER")}
                    className="text-gray-300 hover:text-yellow-500 text-left"
                  >
                    Bankalar ve Finansal Hizmetler
                  </button>
                </li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold mb-4">İletişim</h4>
              <div className="space-y-2 text-sm text-gray-300">
                <p className="flex items-center">
                  <Phone className="h-4 w-4 mr-2" />
                  {siteSettings.phone}
                </p>
                <p className="flex items-center">
                  <Mail className="h-4 w-4 mr-2" />
                  {siteSettings.email}
                </p>
                <p className="text-gray-400">İzmir, Türkiye</p>
              </div>
            </div>
          </div>
          <div className="border-t border-gray-700 mt-8 pt-8 text-center text-sm text-gray-400">
            <p>&copy; 2024 İzmir Rehber. Tüm hakları saklıdır.</p>
          </div>
        </div>
      </footer>
    </div>
  )
}
