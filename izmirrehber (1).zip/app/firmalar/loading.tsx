import { Skeleton } from "@/components/ui/skeleton"
import { Card, CardContent } from "@/components/ui/card"

export default function Loading() {
  return (
    <div className="min-h-screen bg-gray-100">
      {/* Top Header Skeleton */}
      <div className="bg-white border-b">
        <div className="container mx-auto px-4 py-2">
          <div className="flex justify-between items-center">
            <div className="flex items-center space-x-6">
              <Skeleton className="h-4 w-32" />
              <Skeleton className="h-4 w-32" />
            </div>
            <div className="flex space-x-2">
              {[...Array(6)].map((_, i) => (
                <Skeleton key={i} className="w-6 h-6 rounded-full" />
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Header Skeleton */}
      <div className="bg-white shadow-sm">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-center">
            <div className="flex items-center">
              <Skeleton className="w-12 h-12 rounded-lg mr-3" />
              <Skeleton className="h-8 w-48" />
            </div>
          </div>
        </div>
      </div>

      {/* Navigation Skeleton */}
      <div className="bg-yellow-500">
        <div className="container mx-auto px-4">
          <div className="flex items-center justify-center">
            <div className="flex space-x-16">
              {[...Array(3)].map((_, i) => (
                <Skeleton key={i} className="h-16 w-32 bg-yellow-400" />
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Breadcrumb Skeleton */}
      <div className="bg-white border-b">
        <div className="container mx-auto px-4 py-3">
          <Skeleton className="h-4 w-48" />
        </div>
      </div>

      {/* Main Content Skeleton */}
      <div className="container mx-auto px-4 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
          {/* Sidebar Skeleton */}
          <div className="lg:col-span-1">
            {/* Search Card */}
            <Card className="mb-6">
              <div className="bg-blue-600 p-4">
                <Skeleton className="h-6 w-24 bg-blue-500" />
              </div>
              <div className="p-4">
                <Skeleton className="h-10 w-full mb-4" />
                <Skeleton className="h-10 w-full" />
              </div>
            </Card>

            {/* Categories Card */}
            <Card className="mb-6">
              <div className="bg-slate-700 p-4">
                <Skeleton className="h-6 w-32 bg-slate-600" />
              </div>
              <div className="p-4">
                {[...Array(8)].map((_, i) => (
                  <div key={i} className="flex items-center justify-between p-3 border-b">
                    <div className="flex items-center">
                      <Skeleton className="w-4 h-4 rounded-full mr-3" />
                      <Skeleton className="h-4 w-32" />
                    </div>
                    <Skeleton className="h-4 w-8" />
                  </div>
                ))}
              </div>
            </Card>

            {/* Filter Summary Card */}
            <Card>
              <div className="bg-green-600 p-4">
                <Skeleton className="h-6 w-28 bg-green-500" />
              </div>
              <div className="p-4">
                {[...Array(3)].map((_, i) => (
                  <div key={i} className="flex justify-between mb-2">
                    <Skeleton className="h-4 w-20" />
                    <Skeleton className="h-4 w-8" />
                  </div>
                ))}
              </div>
            </Card>
          </div>

          {/* Companies List Skeleton */}
          <div className="lg:col-span-3">
            {/* Header */}
            <div className="flex items-center justify-between mb-6">
              <div>
                <Skeleton className="h-8 w-48 mb-2" />
                <Skeleton className="h-4 w-64" />
              </div>
              <div className="flex space-x-2">
                <Skeleton className="h-8 w-8" />
                <Skeleton className="h-8 w-8" />
              </div>
            </div>

            {/* Companies */}
            <div className="space-y-6">
              {[...Array(6)].map((_, i) => (
                <Card key={i}>
                  <CardContent className="p-6">
                    <div className="flex items-start space-x-4">
                      <Skeleton className="w-20 h-20 rounded-lg flex-shrink-0" />
                      <div className="flex-1">
                        <div className="flex items-center space-x-2 mb-2">
                          <Skeleton className="h-6 w-48" />
                          <Skeleton className="h-5 w-16" />
                        </div>
                        <Skeleton className="h-4 w-32 mb-1" />
                        <Skeleton className="h-3 w-24 mb-2" />
                        <Skeleton className="h-4 w-full mb-4" />

                        <div className="grid grid-cols-1 md:grid-cols-3 gap-3 mb-4">
                          <Skeleton className="h-4 w-32" />
                          <Skeleton className="h-4 w-40" />
                          <Skeleton className="h-4 w-28" />
                        </div>

                        <div className="flex items-center justify-between">
                          <div className="flex items-center">
                            <Skeleton className="h-4 w-16" />
                          </div>
                          <Skeleton className="h-3 w-32" />
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
