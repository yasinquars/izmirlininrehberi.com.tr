"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import {
  Search,
  Phone,
  Mail,
  Star,
  MapPin,
  ChevronRight,
  ChevronDown,
  Building2,
  Grid3X3,
  List,
  Filter,
  Home,
  Briefcase,
  Calendar,
} from "lucide-react"
import Link from "next/link"

interface Company {
  id: number
  name: string
  category: string
  subcategory?: string
  description: string
  phone: string
  email: string
  address: string
  website?: string
  image: string
  rating: number
  reviews: number
  isGold: boolean
  isFeatured: boolean
  joinDate: string
}

interface Category {
  id: number
  name: string
  slug: string
  icon: string
  parentId?: number
  subcategories?: Category[]
  isActive: boolean
  order: number
}

interface SiteSettings {
  phone: string
  email: string
  heroImage: string
  logo: string
  siteName: string
}

export default function FirmalarPage() {
  const [companies, setCompanies] = useState<Company[]>([])
  const [categories, setCategories] = useState<Category[]>([])
  const [expandedCategories, setExpandedCategories] = useState<number[]>([])
  const [selectedCategory, setSelectedCategory] = useState<string>("")
  const [selectedSubcategory, setSelectedSubcategory] = useState<string>("")
  const [siteSettings, setSiteSettings] = useState<SiteSettings>({
    phone: "0 850 303 81 08",
    email: "info@izmirrehber.com",
    heroImage: "",
    logo: "",
    siteName: "izmirrehber",
  })
  const [searchTerm, setSearchTerm] = useState("")
  const [sortBy, setSortBy] = useState("name")
  const [viewMode, setViewMode] = useState<"grid" | "list">("list")

  // Verileri yükle
  useEffect(() => {
    // Site ayarlarını yükle
    const savedSettings = localStorage.getItem("siteSettings")
    if (savedSettings) {
      setSiteSettings(JSON.parse(savedSettings))
    }

    // Şirketleri yükle
    const savedCompanies = localStorage.getItem("companies")
    if (savedCompanies) {
      setCompanies(JSON.parse(savedCompanies))
    }

    // Kategorileri yükle
    const savedCategories = localStorage.getItem("categories")
    if (savedCategories) {
      setCategories(JSON.parse(savedCategories))
    }
  }, [])

  // Ana kategorileri al
  const getMainCategories = () => {
    return categories.filter((cat) => !cat.parentId && cat.isActive).sort((a, b) => a.order - b.order)
  }

  // Alt kategorileri al
  const getSubCategories = (parentId: number) => {
    return categories.filter((cat) => cat.parentId === parentId && cat.isActive).sort((a, b) => a.order - b.order)
  }

  // Kategori genişletme/daraltma
  const toggleCategory = (categoryId: number) => {
    setExpandedCategories((prev) =>
      prev.includes(categoryId) ? prev.filter((id) => id !== categoryId) : [...prev, categoryId],
    )
  }

  // Kategori filtreleme
  const handleCategoryFilter = (categoryName: string) => {
    setSelectedCategory(categoryName)
    setSelectedSubcategory("")
  }

  // Alt kategori filtreleme
  const handleSubcategoryFilter = (subcategoryName: string) => {
    setSelectedSubcategory(subcategoryName)
  }

  // Filtreleri temizle
  const clearFilters = () => {
    setSelectedCategory("")
    setSelectedSubcategory("")
    setSearchTerm("")
  }

  // Filtrelenmiş ve sıralanmış şirketler
  const getFilteredAndSortedCompanies = () => {
    let filtered = companies

    // Kategori filtresi
    if (selectedCategory) {
      filtered = filtered.filter((company) => company.category === selectedCategory)
    }

    // Alt kategori filtresi
    if (selectedSubcategory) {
      filtered = filtered.filter((company) => company.subcategory === selectedSubcategory)
    }

    // Arama filtresi
    if (searchTerm) {
      filtered = filtered.filter(
        (company) =>
          company.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
          company.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
          company.category.toLowerCase().includes(searchTerm.toLowerCase()),
      )
    }

    // Sıralama
    filtered.sort((a, b) => {
      switch (sortBy) {
        case "name":
          return a.name.localeCompare(b.name)
        case "rating":
          return b.rating - a.rating
        case "joinDate":
          return new Date(b.joinDate).getTime() - new Date(a.joinDate).getTime()
        default:
          return 0
      }
    })

    return filtered
  }

  const filteredCompanies = getFilteredAndSortedCompanies()

  return (
    <div className="min-h-screen bg-gray-100">
      {/* Top Header */}
      <div className="bg-white border-b">
        <div className="container mx-auto px-4 py-2">
          <div className="flex justify-between items-center text-sm">
            <div className="flex items-center space-x-6">
              <div className="flex items-center text-gray-600">
                <Mail className="h-4 w-4 mr-1" />
                {siteSettings.email}
              </div>
              <div className="flex items-center text-gray-600">
                <Phone className="h-4 w-4 mr-1" />
                {siteSettings.phone}
              </div>
            </div>
            <div className="flex items-center space-x-4">
              <div className="flex space-x-2">
                {/* Social Media Icons */}
                <div className="w-6 h-6 bg-blue-600 rounded-full flex items-center justify-center">
                  <span className="text-white text-xs">f</span>
                </div>
                <div className="w-6 h-6 bg-blue-400 rounded-full flex items-center justify-center">
                  <span className="text-white text-xs">t</span>
                </div>
                <div className="w-6 h-6 bg-red-600 rounded-full flex items-center justify-center">
                  <span className="text-white text-xs">g</span>
                </div>
                <div className="w-6 h-6 bg-blue-700 rounded-full flex items-center justify-center">
                  <span className="text-white text-xs">in</span>
                </div>
                <div className="w-6 h-6 bg-red-500 rounded-full flex items-center justify-center">
                  <span className="text-white text-xs">y</span>
                </div>
                <div className="w-6 h-6 bg-green-600 rounded-full flex items-center justify-center">
                  <span className="text-white text-xs">w</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Main Header */}
      <header className="bg-white shadow-sm">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-center">
            <div className="flex items-center">
              <div className="w-12 h-12 bg-yellow-500 rounded-lg flex items-center justify-center mr-3">
                <span className="text-white font-bold text-xl">İ</span>
              </div>
              <div>
                <h1 className="text-2xl font-bold text-gray-900">
                  izmir<span className="text-yellow-500">rehber</span>
                </h1>
              </div>
            </div>
          </div>
        </div>
      </header>

      {/* Navigation */}
      <nav className="bg-yellow-500">
        <div className="container mx-auto px-4">
          <div className="flex items-center justify-center">
            <div className="flex space-x-16">
              <Link href="/" className="flex items-center py-3 text-black hover:text-gray-700">
                <div className="flex items-center">
                  <Home className="h-5 w-5 mr-2" />
                  <div className="flex flex-col">
                    <span className="font-semibold text-sm">ANASAYFA</span>
                    <span className="text-xs">Firma rehberi anasayfanız</span>
                  </div>
                </div>
              </Link>
              <Link
                href="/firmalar"
                className="flex items-center py-3 text-black hover:text-gray-700 bg-yellow-600 px-4 rounded"
              >
                <div className="flex items-center">
                  <Briefcase className="h-5 w-5 mr-2" />
                  <div className="flex flex-col">
                    <span className="font-semibold text-sm">FİRMALAR</span>
                    <span className="text-xs">Kayıtlı firmalar</span>
                  </div>
                </div>
              </Link>
              <Link href="/fuar-etkinlikler" className="flex items-center py-3 text-black hover:text-gray-700">
                <div className="flex items-center">
                  <Calendar className="h-5 w-5 mr-2" />
                  <div className="flex flex-col">
                    <span className="font-semibold text-sm">FUAR & ETKİNLİKLER</span>
                    <span className="text-xs">Yaklaşan fuar ve etkinlikler</span>
                  </div>
                </div>
              </Link>
            </div>
          </div>
        </div>
      </nav>

      {/* Breadcrumb */}
      <div className="bg-white border-b">
        <div className="container mx-auto px-4 py-3">
          <div className="flex items-center text-sm text-gray-600">
            <Link href="/" className="hover:text-yellow-600">
              Anasayfa
            </Link>
            <ChevronRight className="h-4 w-4 mx-2" />
            <span className="text-gray-900 font-medium">Firmalar</span>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="container mx-auto px-4 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
          {/* Sidebar - Categories & Filters */}
          <div className="lg:col-span-1">
            {/* Search */}
            <Card className="mb-6">
              <div className="bg-blue-600 text-white p-4 flex items-center">
                <Search className="h-5 w-5 mr-2" />
                <h2 className="font-bold text-lg">ARAMA</h2>
              </div>
              <div className="p-4">
                <Input
                  placeholder="Firma adı veya hizmet ara..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="mb-4"
                />
                <Select value={sortBy} onValueChange={setSortBy}>
                  <SelectTrigger>
                    <SelectValue placeholder="Sıralama" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="name">İsme Göre (A-Z)</SelectItem>
                    <SelectItem value="rating">Puana Göre</SelectItem>
                    <SelectItem value="joinDate">Katılım Tarihine Göre</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </Card>

            {/* Categories */}
            <Card className="mb-6">
              <div className="bg-slate-700 text-white p-4 flex items-center">
                <div className="w-6 h-6 bg-yellow-500 rounded mr-3 flex items-center justify-center">
                  <span className="text-black text-sm font-bold">≡</span>
                </div>
                <h2 className="font-bold text-lg">KATEGORİLER</h2>
              </div>
              <div className="bg-white">
                {/* Filtre temizleme butonu */}
                {(selectedCategory || selectedSubcategory || searchTerm) && (
                  <div className="p-3 border-b bg-yellow-50">
                    <Button onClick={clearFilters} size="sm" variant="outline" className="w-full text-xs bg-white">
                      Tüm Filtreleri Temizle
                    </Button>
                  </div>
                )}

                {getMainCategories().map((category) => {
                  const subCategories = getSubCategories(category.id)
                  const isExpanded = expandedCategories.includes(category.id)
                  const hasSubCategories = subCategories.length > 0
                  const isSelectedCategory = selectedCategory === category.name

                  return (
                    <div key={category.id} className="border-b border-gray-200 last:border-b-0">
                      <div
                        className={`flex items-center justify-between p-3 hover:bg-gray-50 transition-colors group ${
                          isSelectedCategory ? "bg-yellow-50 border-l-4 border-yellow-500" : ""
                        }`}
                      >
                        <button
                          onClick={() => handleCategoryFilter(category.name)}
                          className="flex items-center flex-1 text-left"
                        >
                          <div className="w-4 h-4 bg-gray-400 rounded-full mr-3"></div>
                          <span
                            className={`text-sm font-medium group-hover:text-yellow-600 ${
                              isSelectedCategory ? "text-yellow-600 font-semibold" : "text-gray-700"
                            }`}
                          >
                            {category.name}
                          </span>
                        </button>
                        <div className="flex items-center">
                          <span className="text-xs text-gray-500 mr-2">
                            ({companies.filter((c) => c.category === category.name).length})
                          </span>
                          {hasSubCategories && (
                            <button
                              onClick={() => toggleCategory(category.id)}
                              className="p-1 hover:bg-gray-100 rounded"
                            >
                              {isExpanded ? (
                                <ChevronDown className="h-4 w-4 text-gray-400" />
                              ) : (
                                <ChevronRight className="h-4 w-4 text-gray-400" />
                              )}
                            </button>
                          )}
                        </div>
                      </div>

                      {/* Alt Kategoriler */}
                      {hasSubCategories && isExpanded && (
                        <div className="bg-gray-50 border-t">
                          {subCategories.map((subCategory) => {
                            const isSelectedSubcategory = selectedSubcategory === subCategory.name
                            return (
                              <button
                                key={subCategory.id}
                                onClick={() => handleSubcategoryFilter(subCategory.name)}
                                className={`w-full flex items-center justify-between p-3 pl-8 hover:bg-gray-100 transition-colors group text-left ${
                                  isSelectedSubcategory ? "bg-yellow-100 border-l-4 border-yellow-500" : ""
                                }`}
                              >
                                <div className="flex items-center">
                                  <div className="w-3 h-3 bg-gray-300 rounded-full mr-3"></div>
                                  <span
                                    className={`text-sm group-hover:text-yellow-600 ${
                                      isSelectedSubcategory ? "text-yellow-600 font-semibold" : "text-gray-600"
                                    }`}
                                  >
                                    {subCategory.name}
                                  </span>
                                </div>
                                <div className="flex items-center">
                                  <span className="text-xs text-gray-400 mr-2">
                                    ({companies.filter((c) => c.subcategory === subCategory.name).length})
                                  </span>
                                  <ChevronRight className="h-3 w-3 text-gray-300 group-hover:text-yellow-500" />
                                </div>
                              </button>
                            )
                          })}
                        </div>
                      )}
                    </div>
                  )
                })}
              </div>
            </Card>

            {/* Filter Summary */}
            <Card>
              <div className="bg-green-600 text-white p-4 flex items-center">
                <Filter className="h-5 w-5 mr-2" />
                <h2 className="font-bold text-lg">FİLTRE ÖZETİ</h2>
              </div>
              <div className="p-4">
                <div className="space-y-2 text-sm">
                  <div className="flex justify-between">
                    <span>Toplam Firma:</span>
                    <span className="font-semibold">{companies.length}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Filtrelenmiş:</span>
                    <span className="font-semibold text-blue-600">{filteredCompanies.length}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Gold Firmalar:</span>
                    <span className="font-semibold text-yellow-600">
                      {filteredCompanies.filter((c) => c.isGold).length}
                    </span>
                  </div>
                </div>
              </div>
            </Card>
          </div>

          {/* Companies List */}
          <div className="lg:col-span-3">
            {/* Header */}
            <div className="flex items-center justify-between mb-6">
              <div>
                <h1 className="text-2xl font-bold text-gray-900 mb-2">TÜM FİRMALAR</h1>
                <p className="text-gray-600">
                  {filteredCompanies.length} firma listeleniyor
                  {selectedCategory && <span className="text-blue-600 font-medium"> - {selectedCategory}</span>}
                  {selectedSubcategory && <span className="text-green-600 font-medium"> - {selectedSubcategory}</span>}
                </p>
              </div>
              <div className="flex items-center space-x-2">
                <Button
                  variant={viewMode === "list" ? "default" : "outline"}
                  size="sm"
                  onClick={() => setViewMode("list")}
                >
                  <List className="h-4 w-4" />
                </Button>
                <Button
                  variant={viewMode === "grid" ? "default" : "outline"}
                  size="sm"
                  onClick={() => setViewMode("grid")}
                >
                  <Grid3X3 className="h-4 w-4" />
                </Button>
              </div>
            </div>

            {/* Companies */}
            {filteredCompanies.length > 0 ? (
              <div
                className={viewMode === "grid" ? "grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6" : "space-y-6"}
              >
                {filteredCompanies.map((company) => (
                  <Card key={company.id} className="hover:shadow-lg transition-shadow border">
                    <CardContent className={viewMode === "grid" ? "p-4 text-center" : "p-6"}>
                      {viewMode === "grid" ? (
                        // Grid View
                        <>
                          <div className="relative mb-3">
                            {company.isGold && (
                              <Badge className="absolute -top-2 -right-2 bg-yellow-500 text-black text-xs px-2 py-1 rounded-full">
                                GOLD
                              </Badge>
                            )}
                            <div className="w-20 h-20 mx-auto bg-gray-100 rounded-lg flex items-center justify-center">
                              <Building2 className="h-10 w-10 text-gray-400" />
                            </div>
                          </div>
                          <h3 className="font-semibold text-sm mb-1 text-gray-900">{company.name}</h3>
                          <p className="text-xs text-gray-600 mb-1">{company.category}</p>
                          {company.subcategory && <p className="text-xs text-gray-500 mb-2">• {company.subcategory}</p>}
                          <div className="flex items-center justify-center mb-2">
                            <Star className="h-4 w-4 text-yellow-400 fill-current" />
                            <span className="text-sm ml-1">{company.rating}</span>
                            <span className="text-xs text-gray-500 ml-1">({company.reviews})</span>
                          </div>
                          <p className="text-xs text-gray-500">{company.joinDate} TARİHİNDE KATILDI</p>
                        </>
                      ) : (
                        // List View
                        <div className="flex items-start space-x-4">
                          <div className="w-20 h-20 bg-gray-100 rounded-lg flex items-center justify-center flex-shrink-0">
                            <Building2 className="h-10 w-10 text-gray-400" />
                          </div>
                          <div className="flex-1">
                            <div className="flex items-center space-x-2 mb-2">
                              <h4 className="font-semibold text-lg">{company.name}</h4>
                              {company.isGold && (
                                <Badge className="bg-yellow-500 text-black text-xs px-2 py-1">GOLD FİRMA</Badge>
                              )}
                              {company.isFeatured && (
                                <Badge className="bg-blue-500 text-white text-xs ml-1">VİTRİN</Badge>
                              )}
                            </div>
                            <p className="text-sm text-gray-600 mb-1">{company.category}</p>
                            {company.subcategory && (
                              <p className="text-xs text-gray-500 mb-2">• {company.subcategory}</p>
                            )}
                            <p className="text-sm text-gray-500 mb-4">{company.description}</p>

                            <div className="grid grid-cols-1 md:grid-cols-3 gap-3 text-sm text-gray-600 mb-4">
                              <div className="flex items-center">
                                <Phone className="h-4 w-4 mr-2 text-gray-400" />
                                {company.phone}
                              </div>
                              <div className="flex items-center">
                                <Mail className="h-4 w-4 mr-2 text-gray-400" />
                                {company.email}
                              </div>
                              <div className="flex items-center">
                                <MapPin className="h-4 w-4 mr-2 text-gray-400" />
                                {company.address}
                              </div>
                            </div>

                            <div className="flex items-center justify-between">
                              <div className="flex items-center">
                                <Star className="h-4 w-4 text-yellow-400 fill-current" />
                                <span className="text-sm ml-1 font-medium">{company.rating}</span>
                                <span className="text-xs text-gray-500 ml-1">({company.reviews} değerlendirme)</span>
                              </div>
                              <span className="text-xs text-gray-500">{company.joinDate} tarihinde katıldı</span>
                            </div>
                          </div>
                        </div>
                      )}
                    </CardContent>
                  </Card>
                ))}
              </div>
            ) : (
              <div className="text-center py-12">
                <div className="mb-4">
                  <Search className="h-16 w-16 text-gray-300 mx-auto mb-4" />
                  <h3 className="text-lg font-semibold text-gray-600 mb-2">Sonuç Bulunamadı</h3>
                  <p className="text-gray-500 text-sm">
                    Arama kriterlerinize uygun firma bulunamadı. Farklı anahtar kelimeler deneyebilirsiniz.
                  </p>
                </div>
                <Button onClick={clearFilters} className="bg-yellow-500 hover:bg-yellow-600 text-black">
                  Filtreleri Temizle
                </Button>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Footer */}
      <footer className="bg-slate-800 text-white py-12">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            <div>
              <div className="flex items-center mb-4">
                <div className="w-8 h-8 bg-yellow-500 rounded flex items-center justify-center mr-2">
                  <span className="text-black font-bold">İ</span>
                </div>
                <span className="text-xl font-bold">
                  izmir<span className="text-yellow-500">rehber</span>
                </span>
              </div>
              <p className="text-gray-300 text-sm">
                İzmir'in en kapsamlı iş rehberi. Tüm sektörlerden firmaları keşfedin.
              </p>
            </div>
            <div>
              <h4 className="font-semibold mb-4">Hızlı Linkler</h4>
              <ul className="space-y-2 text-sm">
                <li>
                  <Link href="/" className="text-gray-300 hover:text-yellow-500">
                    Anasayfa
                  </Link>
                </li>
                <li>
                  <Link href="/firmalar" className="text-gray-300 hover:text-yellow-500">
                    Firmalar
                  </Link>
                </li>
                <li>
                  <Link href="/fuar-etkinlikler" className="text-gray-300 hover:text-yellow-500">
                    Fuar ve Etkinlikler
                  </Link>
                </li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold mb-4">Popüler Kategoriler</h4>
              <ul className="space-y-2 text-sm">
                <li>
                  <button
                    onClick={() => handleCategoryFilter("BİLGİSAYAR - ELEKTRONİK")}
                    className="text-gray-300 hover:text-yellow-500 text-left"
                  >
                    Bilgisayar - Elektronik
                  </button>
                </li>
                <li>
                  <button
                    onClick={() => handleCategoryFilter("HİZMET SEKTÖRÜ")}
                    className="text-gray-300 hover:text-yellow-500 text-left"
                  >
                    Hizmet Sektörü
                  </button>
                </li>
                <li>
                  <button
                    onClick={() => handleCategoryFilter("BANKALAR VE FİNANSAL HİZMETLER")}
                    className="text-gray-300 hover:text-yellow-500 text-left"
                  >
                    Bankalar ve Finansal Hizmetler
                  </button>
                </li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold mb-4">İletişim</h4>
              <div className="space-y-2 text-sm text-gray-300">
                <p className="flex items-center">
                  <Phone className="h-4 w-4 mr-2" />
                  {siteSettings.phone}
                </p>
                <p className="flex items-center">
                  <Mail className="h-4 w-4 mr-2" />
                  {siteSettings.email}
                </p>
                <p className="text-gray-400">İzmir, Türkiye</p>
              </div>
            </div>
          </div>
          <div className="border-t border-gray-700 mt-8 pt-8 text-center text-sm text-gray-400">
            <p>&copy; 2024 İzmir Rehber. Tüm hakları saklıdır.</p>
          </div>
        </div>
      </footer>
    </div>
  )
}
