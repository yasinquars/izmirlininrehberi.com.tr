"use client"

import React from "react"
import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog"
import { Label } from "@/components/ui/label"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import {
  Trash2,
  Edit,
  Plus,
  Star,
  Phone,
  Mail,
  MapPin,
  Lock,
  User,
  Settings,
  ChevronDown,
  ChevronRight,
  Calendar,
  Clock,
  Users,
  Building2,
} from "lucide-react"

interface Company {
  id: number
  name: string
  category: string
  description: string
  phone: string
  email: string
  address: string
  website?: string
  image: string
  rating: number
  reviews: number
  isGold: boolean
  isFeatured: boolean
  joinDate: string
}

interface SiteSettings {
  phone: string
  email: string
  heroImage: string
  logo: string
  siteName: string
}

interface Category {
  id: number
  name: string
  slug: string
  icon: string
  parentId?: number
  subcategories?: Category[]
  isActive: boolean
  order: number
}

interface Event {
  id: number
  title: string
  category: string
  description: string
  date: string
  time: string
  location: string
  organizer: string
  image: string
  price: string
  capacity: number
  registered: number
  isGold: boolean
  isFeatured: boolean
}

export default function AdminPanel() {
  const [isLoggedIn, setIsLoggedIn] = useState(false)
  const [loginData, setLoginData] = useState({ username: "", password: "" })
  const [loginError, setLoginError] = useState("")

  const [siteSettings, setSiteSettings] = useState<SiteSettings>({
    phone: "0232 123 45 67",
    email: "info@izmirrehber.com",
    heroImage: "",
    logo: "",
    siteName: "izmirrehber",
  })

  const [companies, setCompanies] = useState<Company[]>([])
  const [isDialogOpen, setIsDialogOpen] = useState(false)
  const [editingCompany, setEditingCompany] = useState<Company | null>(null)
  const [formData, setFormData] = useState({
    name: "",
    category: "",
    description: "",
    phone: "",
    email: "",
    address: "",
    website: "",
    image: "",
    isGold: false,
    isFeatured: false,
  })

  const [categories, setCategories] = useState<Category[]>([])
  const [isCategoryDialogOpen, setIsCategoryDialogOpen] = useState(false)
  const [editingCategory, setEditingCategory] = useState<Category | null>(null)
  const [categoryFormData, setCategoryFormData] = useState({
    name: "",
    slug: "",
    icon: "",
    parentId: undefined as number | undefined,
    isActive: true,
    order: 0,
  })
  const [expandedCategories, setExpandedCategories] = useState<Set<number>>(new Set())

  const [events, setEvents] = useState<Event[]>([])
  const [isEventDialogOpen, setIsEventDialogOpen] = useState(false)
  const [editingEvent, setEditingEvent] = useState<Event | null>(null)
  const [eventFormData, setEventFormData] = useState({
    title: "",
    category: "",
    description: "",
    date: "",
    time: "",
    location: "",
    organizer: "",
    image: "",
    price: "",
    capacity: 0,
    registered: 0,
    isGold: false,
    isFeatured: false,
  })

  const eventCategories = [
    "Ticaret",
    "Müzik",
    "Sinema",
    "Gastronomi",
    "Kültür",
    "Spor",
    "Teknoloji",
    "Sanat",
    "Eğitim",
    "Sağlık",
  ]

  // Verileri yükle
  useEffect(() => {
    const savedSettings = localStorage.getItem("siteSettings")
    if (savedSettings) {
      setSiteSettings(JSON.parse(savedSettings))
    }

    const savedCompanies = localStorage.getItem("companies")
    if (savedCompanies) {
      setCompanies(JSON.parse(savedCompanies))
    }

    const savedCategories = localStorage.getItem("categories")
    if (savedCategories) {
      setCategories(JSON.parse(savedCategories))
    } else {
      const defaultCategories = [
        { id: 1, name: "EĞİTİM", slug: "egitim", icon: "GraduationCap", isActive: true, order: 1 },
        { id: 11, name: "Okullar", slug: "okullar", icon: "", parentId: 1, isActive: true, order: 1 },
        { id: 12, name: "Üniversiteler", slug: "universiteler", icon: "", parentId: 1, isActive: true, order: 2 },
        { id: 13, name: "Dershaneler", slug: "dershaneler", icon: "", parentId: 1, isActive: true, order: 3 },
        { id: 14, name: "Dil Kursları", slug: "dil-kurslari", icon: "", parentId: 1, isActive: true, order: 4 },

        { id: 2, name: "SAĞLIK HİZMETLERİ", slug: "saglik-hizmetleri", icon: "Heart", isActive: true, order: 2 },
        { id: 21, name: "Hastaneler", slug: "hastaneler", icon: "", parentId: 2, isActive: true, order: 1 },
        { id: 22, name: "Özel Klinikler", slug: "ozel-klinikler", icon: "", parentId: 2, isActive: true, order: 2 },
        { id: 23, name: "Diş Hekimleri", slug: "dis-hekimleri", icon: "", parentId: 2, isActive: true, order: 3 },
        { id: 24, name: "Eczaneler", slug: "eczaneler", icon: "", parentId: 2, isActive: true, order: 4 },

        { id: 3, name: "HİZMET SEKTÖRÜ", slug: "hizmet-sektoru", icon: "Wrench", isActive: true, order: 3 },
        {
          id: 31,
          name: "Temizlik Hizmetleri",
          slug: "temizlik-hizmetleri",
          icon: "",
          parentId: 3,
          isActive: true,
          order: 1,
        },
        {
          id: 32,
          name: "Güvenlik Hizmetleri",
          slug: "guvenlik-hizmetleri",
          icon: "",
          parentId: 3,
          isActive: true,
          order: 2,
        },
        {
          id: 33,
          name: "Nakliye ve Taşımacılık",
          slug: "nakliye-ve-tasimacilik",
          icon: "",
          parentId: 3,
          isActive: true,
          order: 3,
        },
        { id: 34, name: "Teknik Servis", slug: "teknik-servis", icon: "", parentId: 3, isActive: true, order: 4 },

        {
          id: 4,
          name: "BİLGİSAYAR - ELEKTRONİK",
          slug: "bilgisayar-elektronik",
          icon: "Monitor",
          isActive: true,
          order: 4,
        },
        {
          id: 41,
          name: "Bilgisayar Satış ve Servisi",
          slug: "bilgisayar-satis-ve-servisi",
          icon: "",
          parentId: 4,
          isActive: true,
          order: 1,
        },
        {
          id: 42,
          name: "Yazılım Geliştirme",
          slug: "yazilim-gelistirme",
          icon: "",
          parentId: 4,
          isActive: true,
          order: 2,
        },
        { id: 43, name: "Web Tasarım", slug: "web-tasarim", icon: "", parentId: 4, isActive: true, order: 3 },
        { id: 44, name: "Elektronik Eşya", slug: "elektronik-esya", icon: "", parentId: 4, isActive: true, order: 4 },

        { id: 5, name: "İNŞAAT VE YAPI", slug: "insaat-ve-yapi", icon: "Building2", isActive: true, order: 5 },
        { id: 51, name: "İnşaat Firmaları", slug: "insaat-firmalari", icon: "", parentId: 5, isActive: true, order: 1 },
        {
          id: 52,
          name: "Mimarlık Büroları",
          slug: "mimarlik-burolari",
          icon: "",
          parentId: 5,
          isActive: true,
          order: 2,
        },
        { id: 53, name: "İç Mimarlık", slug: "ic-mimarlik", icon: "", parentId: 5, isActive: true, order: 3 },
        { id: 54, name: "Yapı Malzemeleri", slug: "yapi-malzemeleri", icon: "", parentId: 5, isActive: true, order: 4 },

        { id: 6, name: "TURİZM VE OTEL", slug: "turizm-ve-otel", icon: "Car", isActive: true, order: 6 },
        { id: 61, name: "Oteller", slug: "oteller", icon: "", parentId: 6, isActive: true, order: 1 },
        {
          id: 62,
          name: "Seyahat Acenteleri",
          slug: "seyahat-acenteleri",
          icon: "",
          parentId: 6,
          isActive: true,
          order: 2,
        },
        { id: 63, name: "Tur Operatörleri", slug: "tur-operatorleri", icon: "", parentId: 6, isActive: true, order: 3 },
        { id: 64, name: "Araç Kiralama", slug: "arac-kiralama", icon: "", parentId: 6, isActive: true, order: 4 },

        { id: 7, name: "YEME İÇME", slug: "yeme-icme", icon: "Utensils", isActive: true, order: 7 },
        { id: 71, name: "Restoranlar", slug: "restoranlar", icon: "", parentId: 7, isActive: true, order: 1 },
        { id: 72, name: "Kafeler", slug: "kafeler", icon: "", parentId: 7, isActive: true, order: 2 },
        { id: 73, name: "Fast Food", slug: "fast-food", icon: "", parentId: 7, isActive: true, order: 3 },
        { id: 74, name: "Pastaneler", slug: "pastaneler", icon: "", parentId: 7, isActive: true, order: 4 },
      ]
      setCategories(defaultCategories)
      localStorage.setItem("categories", JSON.stringify(defaultCategories))
    }

    const savedEvents = localStorage.getItem("events")
    if (savedEvents) {
      setEvents(JSON.parse(savedEvents))
    } else {
      const defaultEvents = [
        {
          id: 1,
          title: "İzmir Enternasyonal Fuarı 2024",
          category: "Ticaret",
          description:
            "Türkiye'nin en köklü fuarlarından İzmir Enternasyonal Fuarı, 90 yıllık geçmişi ile sektörleri buluşturuyor.",
          date: "20 Ağustos - 4 Eylül 2024",
          time: "10:00 - 22:00",
          location: "İzmir Fuar Merkezi, Gaziemir",
          organizer: "İZFAŞ - İzmir Büyükşehir Belediyesi",
          image: "/placeholder.svg?height=200&width=300",
          price: "Ücretsiz",
          capacity: 500000,
          registered: 125000,
          isGold: true,
          isFeatured: true,
        },
        {
          id: 2,
          title: "İzmir Avrupa Caz Festivali",
          category: "Müzik",
          description: "Dünyaca ünlü caz sanatçılarının İzmir'de buluştuğu prestijli festival.",
          date: "15-25 Mart 2024",
          time: "20:00 - 24:00",
          location: "Çeşitli Mekanlar (Alsancak, Kemeraltı)",
          organizer: "İzmir Büyükşehir Belediyesi",
          image: "/placeholder.svg?height=200&width=300",
          price: "50-150 TL",
          capacity: 15000,
          registered: 8500,
          isGold: true,
          isFeatured: true,
        },
      ]
      setEvents(defaultEvents)
      localStorage.setItem("events", JSON.stringify(defaultEvents))
    }
  }, [])

  // Ana kategorileri al
  const getMainCategories = () => {
    return categories.filter((cat) => !cat.parentId).sort((a, b) => a.order - b.order)
  }

  // Alt kategorileri al
  const getSubCategories = (parentId: number) => {
    return categories.filter((cat) => cat.parentId === parentId).sort((a, b) => a.order - b.order)
  }

  // Site ayarlarını kaydet
  const handleSaveSettings = () => {
    localStorage.setItem("siteSettings", JSON.stringify(siteSettings))
    alert("Site ayarları başarıyla kaydedildi!")
  }

  // Giriş kontrolü
  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault()

    if (loginData.username === "yasinozen35" && loginData.password === "05438119717") {
      setIsLoggedIn(true)
      setLoginError("")
    } else {
      setLoginError("Kullanıcı adı veya şifre hatalı!")
    }
  }

  const handleLogout = () => {
    setIsLoggedIn(false)
    setLoginData({ username: "", password: "" })
  }

  // Şirket işlemleri
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()

    if (editingCompany) {
      const updatedCompanies = companies.map((company) =>
        company.id === editingCompany.id
          ? {
              ...company,
              ...formData,
              rating: company.rating,
              reviews: company.reviews,
              joinDate: company.joinDate,
              image: formData.image || "/placeholder.svg?height=100&width=100",
            }
          : company,
      )
      setCompanies(updatedCompanies)
      localStorage.setItem("companies", JSON.stringify(updatedCompanies))
    } else {
      const newCompany: Company = {
        id: Date.now(),
        ...formData,
        image: formData.image || "/placeholder.svg?height=100&width=100",
        rating: 5.0,
        reviews: 0,
        joinDate: new Date()
          .toLocaleDateString("tr-TR", {
            day: "numeric",
            month: "long",
            year: "numeric",
          })
          .toUpperCase(),
      }
      const updatedCompanies = [...companies, newCompany]
      setCompanies(updatedCompanies)
      localStorage.setItem("companies", JSON.stringify(updatedCompanies))
    }

    setFormData({
      name: "",
      category: "",
      description: "",
      phone: "",
      email: "",
      address: "",
      website: "",
      image: "",
      isGold: false,
      isFeatured: false,
    })
    setEditingCompany(null)
    setIsDialogOpen(false)
  }

  const handleEdit = (company: Company) => {
    setEditingCompany(company)
    setFormData({
      name: company.name,
      category: company.category,
      description: company.description,
      phone: company.phone,
      email: company.email,
      address: company.address,
      website: company.website || "",
      image: company.image || "",
      isGold: company.isGold,
      isFeatured: company.isFeatured,
    })
    setIsDialogOpen(true)
  }

  const handleDelete = (id: number) => {
    if (confirm("Bu işletmeyi silmek istediğinizden emin misiniz?")) {
      const updatedCompanies = companies.filter((company) => company.id !== id)
      setCompanies(updatedCompanies)
      localStorage.setItem("companies", JSON.stringify(updatedCompanies))
    }
  }

  const openAddDialog = () => {
    setEditingCompany(null)
    setFormData({
      name: "",
      category: "",
      description: "",
      phone: "",
      email: "",
      address: "",
      website: "",
      image: "",
      isGold: false,
      isFeatured: false,
    })
    setIsDialogOpen(true)
  }

  // Kategori işlemleri
  const handleCategorySubmit = (e: React.FormEvent) => {
    e.preventDefault()

    if (editingCategory) {
      const updatedCategories = categories.map((cat) =>
        cat.id === editingCategory.id ? { ...cat, ...categoryFormData } : cat,
      )
      setCategories(updatedCategories)
      localStorage.setItem("categories", JSON.stringify(updatedCategories))
    } else {
      const newCategory: Category = {
        id: Date.now(),
        ...categoryFormData,
      }
      const updatedCategories = [...categories, newCategory]
      setCategories(updatedCategories)
      localStorage.setItem("categories", JSON.stringify(updatedCategories))
    }

    setCategoryFormData({ name: "", slug: "", icon: "", parentId: undefined, isActive: true, order: 0 })
    setEditingCategory(null)
    setIsCategoryDialogOpen(false)
  }

  const handleEditCategory = (category: Category) => {
    setEditingCategory(category)
    setCategoryFormData({
      name: category.name,
      slug: category.slug,
      icon: category.icon,
      parentId: category.parentId,
      isActive: category.isActive,
      order: category.order,
    })
    setIsCategoryDialogOpen(true)
  }

  const handleDeleteCategory = (id: number) => {
    const hasSubcategories = categories.some((cat) => cat.parentId === id)
    if (hasSubcategories) {
      if (!confirm("Bu kategorinin alt kategorileri var. Tümünü silmek istediğinizden emin misiniz?")) {
        return
      }
    }

    if (confirm("Bu kategoriyi silmek istediğinizden emin misiniz?")) {
      const updatedCategories = categories.filter((cat) => cat.id !== id && cat.parentId !== id)
      setCategories(updatedCategories)
      localStorage.setItem("categories", JSON.stringify(updatedCategories))
    }
  }

  const openAddCategoryDialog = (parentId?: number) => {
    setEditingCategory(null)
    const nextOrder = parentId
      ? Math.max(...categories.filter((c) => c.parentId === parentId).map((c) => c.order), 0) + 1
      : Math.max(...categories.filter((c) => !c.parentId).map((c) => c.order), 0) + 1

    setCategoryFormData({
      name: "",
      slug: "",
      icon: parentId ? "" : "Building2",
      parentId,
      isActive: true,
      order: nextOrder,
    })
    setIsCategoryDialogOpen(true)
  }

  const toggleCategory = (categoryId: number) => {
    const newExpanded = new Set(expandedCategories)
    if (newExpanded.has(categoryId)) {
      newExpanded.delete(categoryId)
    } else {
      newExpanded.add(categoryId)
    }
    setExpandedCategories(newExpanded)
  }

  // Etkinlik işlemleri
  const handleEventSubmit = (e: React.FormEvent) => {
    e.preventDefault()

    if (editingEvent) {
      const updatedEvents = events.map((event) =>
        event.id === editingEvent.id
          ? {
              ...event,
              ...eventFormData,
              image: eventFormData.image || "/placeholder.svg?height=200&width=300",
            }
          : event,
      )
      setEvents(updatedEvents)
      localStorage.setItem("events", JSON.stringify(updatedEvents))
    } else {
      const newEvent: Event = {
        id: Date.now(),
        ...eventFormData,
        image: eventFormData.image || "/placeholder.svg?height=200&width=300",
        registered: 0,
      }
      const updatedEvents = [...events, newEvent]
      setEvents(updatedEvents)
      localStorage.setItem("events", JSON.stringify(updatedEvents))
    }

    setEventFormData({
      title: "",
      category: "",
      description: "",
      date: "",
      time: "",
      location: "",
      organizer: "",
      image: "",
      price: "",
      capacity: 0,
      registered: 0,
      isGold: false,
      isFeatured: false,
    })
    setEditingEvent(null)
    setIsEventDialogOpen(false)
  }

  const handleEditEvent = (event: Event) => {
    setEditingEvent(event)
    setEventFormData({
      title: event.title,
      category: event.category,
      description: event.description,
      date: event.date,
      time: event.time,
      location: event.location,
      organizer: event.organizer,
      image: event.image || "",
      price: event.price,
      capacity: event.capacity,
      registered: event.registered,
      isGold: event.isGold,
      isFeatured: event.isFeatured,
    })
    setIsEventDialogOpen(true)
  }

  const handleDeleteEvent = (id: number) => {
    if (confirm("Bu etkinliği silmek istediğinizden emin misiniz?")) {
      const updatedEvents = events.filter((event) => event.id !== id)
      setEvents(updatedEvents)
      localStorage.setItem("events", JSON.stringify(updatedEvents))
    }
  }

  const openAddEventDialog = () => {
    setEditingEvent(null)
    setEventFormData({
      title: "",
      category: "",
      description: "",
      date: "",
      time: "",
      location: "",
      organizer: "",
      image: "",
      price: "",
      capacity: 0,
      registered: 0,
      isGold: false,
      isFeatured: false,
    })
    setIsEventDialogOpen(true)
  }

  // Giriş yapmamışsa login formu göster
  if (!isLoggedIn) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <Card className="w-full max-w-md">
          <CardHeader className="text-center">
            <CardTitle className="text-2xl font-bold">Admin Girişi</CardTitle>
            <p className="text-gray-600">İzmir Rehber Yönetim Paneli</p>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleLogin} className="space-y-4">
              <div>
                <Label htmlFor="username">Kullanıcı Adı</Label>
                <div className="relative">
                  <User className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                  <Input
                    id="username"
                    type="text"
                    placeholder="Kullanıcı adınızı girin"
                    className="pl-10"
                    value={loginData.username}
                    onChange={(e) => setLoginData({ ...loginData, username: e.target.value })}
                    required
                  />
                </div>
              </div>

              <div>
                <Label htmlFor="password">Şifre</Label>
                <div className="relative">
                  <Lock className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                  <Input
                    id="password"
                    type="password"
                    placeholder="Şifrenizi girin"
                    className="pl-10"
                    value={loginData.password}
                    onChange={(e) => setLoginData({ ...loginData, password: e.target.value })}
                    required
                  />
                </div>
              </div>

              {loginError && <div className="text-red-600 text-sm text-center">{loginError}</div>}

              <Button type="submit" className="w-full bg-yellow-500 hover:bg-yellow-600 text-black">
                Giriş Yap
              </Button>
            </form>
          </CardContent>
        </Card>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b">
        <div className="container mx-auto px-4 py-6">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-3xl font-bold text-gray-900">Admin Paneli</h1>
              <p className="text-gray-600 mt-1">İşletmeleri ve site ayarlarını yönetin</p>
            </div>
            <div className="flex space-x-4">
              <Button asChild variant="outline">
                <a href="/">Ana Sayfaya Dön</a>
              </Button>
              <Button variant="outline" onClick={handleLogout}>
                Çıkış Yap
              </Button>
            </div>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-4 py-6">
        <Tabs defaultValue="companies" className="w-full">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="companies">İşletmeler</TabsTrigger>
            <TabsTrigger value="events">Etkinlikler</TabsTrigger>
            <TabsTrigger value="categories">Kategoriler</TabsTrigger>
            <TabsTrigger value="settings">Site Ayarları</TabsTrigger>
          </TabsList>

          {/* İşletmeler Tab */}
          <TabsContent value="companies" className="space-y-6">
            {/* Stats */}
            <div className="grid grid-cols-1 md:grid-cols-5 gap-6">
              <Card>
                <CardContent className="p-6">
                  <div className="text-2xl font-bold text-yellow-600">{companies.length}</div>
                  <p className="text-gray-600">Toplam İşletme</p>
                </CardContent>
              </Card>
              <Card>
                <CardContent className="p-6">
                  <div className="text-2xl font-bold text-yellow-600">{companies.filter((c) => c.isGold).length}</div>
                  <p className="text-gray-600">Gold Üye</p>
                </CardContent>
              </Card>
              <Card>
                <CardContent className="p-6">
                  <div className="text-2xl font-bold text-yellow-600">
                    {companies.filter((c) => c.isFeatured).length}
                  </div>
                  <p className="text-gray-600">Vitrin Firma</p>
                </CardContent>
              </Card>
              <Card>
                <CardContent className="p-6">
                  <div className="text-2xl font-bold text-yellow-600">
                    {new Set(companies.map((c) => c.category)).size}
                  </div>
                  <p className="text-gray-600">Kategori</p>
                </CardContent>
              </Card>
              <Card>
                <CardContent className="p-6">
                  <div className="text-2xl font-bold text-yellow-600">
                    {companies.reduce((sum, c) => sum + c.reviews, 0)}
                  </div>
                  <p className="text-gray-600">Toplam Yorum</p>
                </CardContent>
              </Card>
            </div>

            {/* Add Company Button */}
            <div className="flex justify-end">
              <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
                <DialogTrigger asChild>
                  <Button onClick={openAddDialog} className="bg-yellow-500 hover:bg-yellow-600 text-black">
                    <Plus className="h-4 w-4 mr-2" />
                    Yeni İşletme Ekle
                  </Button>
                </DialogTrigger>
                <DialogContent className="max-w-2xl">
                  <DialogHeader>
                    <DialogTitle>{editingCompany ? "İşletme Düzenle" : "Yeni İşletme Ekle"}</DialogTitle>
                  </DialogHeader>
                  <form onSubmit={handleSubmit} className="space-y-4">
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <Label htmlFor="name">İşletme Adı</Label>
                        <Input
                          id="name"
                          value={formData.name}
                          onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                          required
                        />
                      </div>
                      <div>
                        <Label htmlFor="category">Kategori</Label>
                        <Select
                          value={formData.category}
                          onValueChange={(value) => setFormData({ ...formData, category: value })}
                        >
                          <SelectTrigger>
                            <SelectValue placeholder="Kategori seçin" />
                          </SelectTrigger>
                          <SelectContent>
                            {getMainCategories()
                              .filter((cat) => cat.isActive)
                              .map((mainCat) => (
                                <React.Fragment key={mainCat.id}>
                                  <SelectItem value={mainCat.name} className="font-semibold">
                                    {mainCat.name}
                                  </SelectItem>
                                  {getSubCategories(mainCat.id)
                                    .filter((subCat) => subCat.isActive)
                                    .map((subCat) => (
                                      <SelectItem key={subCat.id} value={subCat.name} className="pl-6">
                                        └ {subCat.name}
                                      </SelectItem>
                                    ))}
                                </React.Fragment>
                              ))}
                          </SelectContent>
                        </Select>
                      </div>
                    </div>

                    <div>
                      <Label htmlFor="description">Açıklama</Label>
                      <Textarea
                        id="description"
                        value={formData.description}
                        onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                        required
                      />
                    </div>

                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <Label htmlFor="phone">Telefon</Label>
                        <Input
                          id="phone"
                          value={formData.phone}
                          onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                          required
                        />
                      </div>
                      <div>
                        <Label htmlFor="email">E-posta</Label>
                        <Input
                          id="email"
                          type="email"
                          value={formData.email}
                          onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                          required
                        />
                      </div>
                    </div>

                    <div>
                      <Label htmlFor="address">Adres</Label>
                      <Input
                        id="address"
                        value={formData.address}
                        onChange={(e) => setFormData({ ...formData, address: e.target.value })}
                        required
                      />
                    </div>

                    <div>
                      <Label htmlFor="website">Website (Opsiyonel)</Label>
                      <Input
                        id="website"
                        value={formData.website}
                        onChange={(e) => setFormData({ ...formData, website: e.target.value })}
                      />
                    </div>

                    <div>
                      <Label htmlFor="image">Fotoğraf</Label>
                      <div className="space-y-2">
                        <Input
                          id="image"
                          type="file"
                          accept="image/*"
                          onChange={(e) => {
                            const file = e.target.files?.[0]
                            if (file) {
                              const reader = new FileReader()
                              reader.onload = (event) => {
                                setFormData({ ...formData, image: event.target?.result as string })
                              }
                              reader.readAsDataURL(file)
                            }
                          }}
                        />
                        <p className="text-xs text-gray-500">
                          JPG, PNG veya GIF formatında fotoğraf yükleyebilirsiniz.
                        </p>
                        {formData.image && (
                          <div className="mt-2">
                            <img
                              src={formData.image || "/placeholder.svg"}
                              alt="Önizleme"
                              className="w-20 h-20 object-cover rounded-lg border"
                            />
                            <Button
                              type="button"
                              variant="outline"
                              size="sm"
                              className="mt-1 bg-transparent"
                              onClick={() => setFormData({ ...formData, image: "" })}
                            >
                              Fotoğrafı Kaldır
                            </Button>
                          </div>
                        )}
                      </div>
                    </div>

                    <div className="flex items-center space-x-4">
                      <div className="flex items-center space-x-2">
                        <input
                          type="checkbox"
                          id="isGold"
                          checked={formData.isGold}
                          onChange={(e) => setFormData({ ...formData, isGold: e.target.checked })}
                          className="rounded"
                        />
                        <Label htmlFor="isGold">Gold Üyelik</Label>
                      </div>

                      <div className="flex items-center space-x-2">
                        <input
                          type="checkbox"
                          id="isFeatured"
                          checked={formData.isFeatured}
                          onChange={(e) => setFormData({ ...formData, isFeatured: e.target.checked })}
                          className="rounded"
                        />
                        <Label htmlFor="isFeatured">Vitrinde Göster</Label>
                      </div>
                    </div>

                    <div className="flex justify-end space-x-2">
                      <Button type="button" variant="outline" onClick={() => setIsDialogOpen(false)}>
                        İptal
                      </Button>
                      <Button type="submit" className="bg-yellow-500 hover:bg-yellow-600 text-black">
                        {editingCompany ? "Güncelle" : "Ekle"}
                      </Button>
                    </div>
                  </form>
                </DialogContent>
              </Dialog>
            </div>

            {/* Companies List */}
            <Card>
              <CardHeader>
                <CardTitle>İşletmeler ({companies.length})</CardTitle>
              </CardHeader>
              <CardContent>
                {companies.length === 0 ? (
                  <div className="text-center py-12">
                    <p className="text-gray-500 text-lg mb-4">Henüz hiç işletme eklenmemiş.</p>
                    <Button onClick={openAddDialog} className="bg-yellow-500 hover:bg-yellow-600 text-black">
                      <Plus className="h-4 w-4 mr-2" />
                      İlk İşletmeyi Ekle
                    </Button>
                  </div>
                ) : (
                  <div className="space-y-4">
                    {companies.map((company) => (
                      <div key={company.id} className="border rounded-lg p-4 hover:shadow-md transition-shadow">
                        <div className="flex items-start justify-between">
                          <div className="flex-1">
                            <div className="flex items-center space-x-2 mb-2">
                              <h3 className="text-lg font-semibold">{company.name}</h3>
                              {company.isGold && <Badge className="bg-yellow-500 text-black">GOLD</Badge>}
                              {company.isFeatured && <Badge className="bg-blue-500 text-white ml-2">VİTRİN</Badge>}
                            </div>
                            <p className="text-gray-600 mb-2">{company.category}</p>
                            <p className="text-sm text-gray-500 mb-3">{company.description}</p>

                            <div className="grid grid-cols-1 md:grid-cols-3 gap-2 text-sm text-gray-600">
                              <div className="flex items-center">
                                <Phone className="h-4 w-4 mr-1" />
                                {company.phone}
                              </div>
                              <div className="flex items-center">
                                <Mail className="h-4 w-4 mr-1" />
                                {company.email}
                              </div>
                              <div className="flex items-center">
                                <MapPin className="h-4 w-4 mr-1" />
                                {company.address}
                              </div>
                            </div>

                            <div className="flex items-center mt-2">
                              <Star className="h-4 w-4 text-yellow-400 fill-current" />
                              <span className="text-sm ml-1">{company.rating}</span>
                              <span className="text-xs text-gray-500 ml-1">({company.reviews} yorum)</span>
                              <span className="text-xs text-gray-500 ml-4">{company.joinDate} tarihinde katıldı</span>
                            </div>
                          </div>

                          <div className="flex space-x-2 ml-4">
                            <Button size="sm" variant="outline" onClick={() => handleEdit(company)}>
                              <Edit className="h-4 w-4" />
                            </Button>
                            <Button
                              size="sm"
                              variant="outline"
                              onClick={() => handleDelete(company.id)}
                              className="text-red-600 hover:text-red-700"
                            >
                              <Trash2 className="h-4 w-4" />
                            </Button>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          {/* Etkinlikler Tab */}
          <TabsContent value="events" className="space-y-6">
            {/* Stats */}
            <div className="grid grid-cols-1 md:grid-cols-5 gap-6">
              <Card>
                <CardContent className="p-6">
                  <div className="text-2xl font-bold text-yellow-600">{events.length}</div>
                  <p className="text-gray-600">Toplam Etkinlik</p>
                </CardContent>
              </Card>
              <Card>
                <CardContent className="p-6">
                  <div className="text-2xl font-bold text-yellow-600">{events.filter((e) => e.isGold).length}</div>
                  <p className="text-gray-600">Gold Etkinlik</p>
                </CardContent>
              </Card>
              <Card>
                <CardContent className="p-6">
                  <div className="text-2xl font-bold text-yellow-600">{events.filter((e) => e.isFeatured).length}</div>
                  <p className="text-gray-600">Öne Çıkan</p>
                </CardContent>
              </Card>
              <Card>
                <CardContent className="p-6">
                  <div className="text-2xl font-bold text-yellow-600">
                    {new Set(events.map((e) => e.category)).size}
                  </div>
                  <p className="text-gray-600">Kategori</p>
                </CardContent>
              </Card>
              <Card>
                <CardContent className="p-6">
                  <div className="text-2xl font-bold text-yellow-600">
                    {events.reduce((sum, e) => sum + e.registered, 0)}
                  </div>
                  <p className="text-gray-600">Toplam Katılımcı</p>
                </CardContent>
              </Card>
            </div>

            {/* Add Event Button */}
            <div className="flex justify-end">
              <Dialog open={isEventDialogOpen} onOpenChange={setIsEventDialogOpen}>
                <DialogTrigger asChild>
                  <Button onClick={openAddEventDialog} className="bg-yellow-500 hover:bg-yellow-600 text-black">
                    <Plus className="h-4 w-4 mr-2" />
                    Yeni Etkinlik Ekle
                  </Button>
                </DialogTrigger>
                <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
                  <DialogHeader>
                    <DialogTitle>{editingEvent ? "Etkinlik Düzenle" : "Yeni Etkinlik Ekle"}</DialogTitle>
                  </DialogHeader>
                  <form onSubmit={handleEventSubmit} className="space-y-4">
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <Label htmlFor="eventTitle">Etkinlik Adı</Label>
                        <Input
                          id="eventTitle"
                          value={eventFormData.title}
                          onChange={(e) => setEventFormData({ ...eventFormData, title: e.target.value })}
                          required
                        />
                      </div>
                      <div>
                        <Label htmlFor="eventCategory">Kategori</Label>
                        <Select
                          value={eventFormData.category}
                          onValueChange={(value) => setEventFormData({ ...eventFormData, category: value })}
                        >
                          <SelectTrigger>
                            <SelectValue placeholder="Kategori seçin" />
                          </SelectTrigger>
                          <SelectContent>
                            {eventCategories.map((category) => (
                              <SelectItem key={category} value={category}>
                                {category}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>
                    </div>

                    <div>
                      <Label htmlFor="eventDescription">Açıklama</Label>
                      <Textarea
                        id="eventDescription"
                        value={eventFormData.description}
                        onChange={(e) => setEventFormData({ ...eventFormData, description: e.target.value })}
                        required
                      />
                    </div>

                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <Label htmlFor="eventDate">Tarih</Label>
                        <Input
                          id="eventDate"
                          placeholder="Örn: 15-25 Mart 2024"
                          value={eventFormData.date}
                          onChange={(e) => setEventFormData({ ...eventFormData, date: e.target.value })}
                          required
                        />
                      </div>
                      <div>
                        <Label htmlFor="eventTime">Saat</Label>
                        <Input
                          id="eventTime"
                          placeholder="Örn: 10:00 - 18:00"
                          value={eventFormData.time}
                          onChange={(e) => setEventFormData({ ...eventFormData, time: e.target.value })}
                          required
                        />
                      </div>
                    </div>

                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <Label htmlFor="eventLocation">Konum</Label>
                        <Input
                          id="eventLocation"
                          value={eventFormData.location}
                          onChange={(e) => setEventFormData({ ...eventFormData, location: e.target.value })}
                          required
                        />
                      </div>
                      <div>
                        <Label htmlFor="eventOrganizer">Organizatör</Label>
                        <Input
                          id="eventOrganizer"
                          value={eventFormData.organizer}
                          onChange={(e) => setEventFormData({ ...eventFormData, organizer: e.target.value })}
                          required
                        />
                      </div>
                    </div>

                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <Label htmlFor="eventPrice">Fiyat</Label>
                        <Input
                          id="eventPrice"
                          placeholder="Örn: Ücretsiz, 50 TL, 25-100 TL"
                          value={eventFormData.price}
                          onChange={(e) => setEventFormData({ ...eventFormData, price: e.target.value })}
                          required
                        />
                      </div>
                      <div>
                        <Label htmlFor="eventCapacity">Kapasite</Label>
                        <Input
                          id="eventCapacity"
                          type="number"
                          value={eventFormData.capacity}
                          onChange={(e) =>
                            setEventFormData({ ...eventFormData, capacity: Number.parseInt(e.target.value) })
                          }
                          required
                        />
                      </div>
                    </div>

                    <div>
                      <Label htmlFor="eventImage">Etkinlik Görseli</Label>
                      <div className="space-y-2">
                        <Input
                          id="eventImage"
                          type="file"
                          accept="image/*"
                          onChange={(e) => {
                            const file = e.target.files?.[0]
                            if (file) {
                              const reader = new FileReader()
                              reader.onload = (event) => {
                                setEventFormData({ ...eventFormData, image: event.target?.result as string })
                              }
                              reader.readAsDataURL(file)
                            }
                          }}
                        />
                        <p className="text-xs text-gray-500">JPG, PNG veya GIF formatında görsel yükleyebilirsiniz.</p>
                        {eventFormData.image && (
                          <div className="mt-2">
                            <img
                              src={eventFormData.image || "/placeholder.svg"}
                              alt="Önizleme"
                              className="w-32 h-20 object-cover rounded-lg border"
                            />
                            <Button
                              type="button"
                              variant="outline"
                              size="sm"
                              className="mt-1 bg-transparent"
                              onClick={() => setEventFormData({ ...eventFormData, image: "" })}
                            >
                              Görseli Kaldır
                            </Button>
                          </div>
                        )}
                      </div>
                    </div>

                    <div className="flex items-center space-x-4">
                      <div className="flex items-center space-x-2">
                        <input
                          type="checkbox"
                          id="eventIsGold"
                          checked={eventFormData.isGold}
                          onChange={(e) => setEventFormData({ ...eventFormData, isGold: e.target.checked })}
                          className="rounded"
                        />
                        <Label htmlFor="eventIsGold">Gold Etkinlik</Label>
                      </div>

                      <div className="flex items-center space-x-2">
                        <input
                          type="checkbox"
                          id="eventIsFeatured"
                          checked={eventFormData.isFeatured}
                          onChange={(e) => setEventFormData({ ...eventFormData, isFeatured: e.target.checked })}
                          className="rounded"
                        />
                        <Label htmlFor="eventIsFeatured">Öne Çıkar</Label>
                      </div>
                    </div>

                    <div className="flex justify-end space-x-2">
                      <Button type="button" variant="outline" onClick={() => setIsEventDialogOpen(false)}>
                        İptal
                      </Button>
                      <Button type="submit" className="bg-yellow-500 hover:bg-yellow-600 text-black">
                        {editingEvent ? "Güncelle" : "Ekle"}
                      </Button>
                    </div>
                  </form>
                </DialogContent>
              </Dialog>
            </div>

            {/* Events List */}
            <Card>
              <CardHeader>
                <CardTitle>Etkinlikler ({events.length})</CardTitle>
              </CardHeader>
              <CardContent>
                {events.length === 0 ? (
                  <div className="text-center py-12">
                    <p className="text-gray-500 text-lg mb-4">Henüz hiç etkinlik eklenmemiş.</p>
                    <Button onClick={openAddEventDialog} className="bg-yellow-500 hover:bg-yellow-600 text-black">
                      <Plus className="h-4 w-4 mr-2" />
                      İlk Etkinliği Ekle
                    </Button>
                  </div>
                ) : (
                  <div className="space-y-4">
                    {events.map((event) => (
                      <div key={event.id} className="border rounded-lg p-4 hover:shadow-md transition-shadow">
                        <div className="flex items-start justify-between">
                          <div className="flex-1">
                            <div className="flex items-center space-x-2 mb-2">
                              <h3 className="text-lg font-semibold">{event.title}</h3>
                              {event.isGold && <Badge className="bg-yellow-500 text-black">GOLD</Badge>}
                              {event.isFeatured && <Badge className="bg-blue-500 text-white ml-2">ÖNE ÇIKAN</Badge>}
                            </div>
                            <p className="text-gray-600 mb-2">{event.category}</p>
                            <p className="text-sm text-gray-500 mb-3">{event.description}</p>

                            <div className="grid grid-cols-1 md:grid-cols-2 gap-2 text-sm text-gray-600 mb-3">
                              <div className="flex items-center">
                                <Calendar className="h-4 w-4 mr-1" />
                                {event.date}
                              </div>
                              <div className="flex items-center">
                                <Clock className="h-4 w-4 mr-1" />
                                {event.time}
                              </div>
                              <div className="flex items-center">
                                <MapPin className="h-4 w-4 mr-1" />
                                {event.location}
                              </div>
                              <div className="flex items-center">
                                <Building2 className="h-4 w-4 mr-1" />
                                {event.organizer}
                              </div>
                            </div>

                            <div className="flex items-center justify-between">
                              <div className="flex items-center space-x-4 text-sm text-gray-600">
                                <div className="flex items-center">
                                  <Users className="h-4 w-4 mr-1" />
                                  {event.registered}/{event.capacity} katılımcı
                                </div>
                                <div className="font-semibold text-yellow-600">{event.price}</div>
                              </div>
                            </div>
                          </div>

                          <div className="flex space-x-2 ml-4">
                            <Button size="sm" variant="outline" onClick={() => handleEditEvent(event)}>
                              <Edit className="h-4 w-4" />
                            </Button>
                            <Button
                              size="sm"
                              variant="outline"
                              onClick={() => handleDeleteEvent(event.id)}
                              className="text-red-600 hover:text-red-700"
                            >
                              <Trash2 className="h-4 w-4" />
                            </Button>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          {/* Kategoriler Tab */}
          <TabsContent value="categories" className="space-y-6">
            {/* Add Category Button */}
            <div className="flex justify-end">
              <Dialog open={isCategoryDialogOpen} onOpenChange={setIsCategoryDialogOpen}>
                <DialogTrigger asChild>
                  <Button
                    onClick={() => openAddCategoryDialog()}
                    className="bg-yellow-500 hover:bg-yellow-600 text-black"
                  >
                    <Plus className="h-4 w-4 mr-2" />
                    Yeni Ana Kategori Ekle
                  </Button>
                </DialogTrigger>
                <DialogContent className="max-w-md">
                  <DialogHeader>
                    <DialogTitle>
                      {editingCategory
                        ? "Kategori Düzenle"
                        : categoryFormData.parentId
                          ? "Alt Kategori Ekle"
                          : "Ana Kategori Ekle"}
                    </DialogTitle>
                  </DialogHeader>
                  <form onSubmit={handleCategorySubmit} className="space-y-4">
                    <div>
                      <Label htmlFor="categoryName">Kategori Adı</Label>
                      <Input
                        id="categoryName"
                        value={categoryFormData.name}
                        onChange={(e) => setCategoryFormData({ ...categoryFormData, name: e.target.value })}
                        placeholder={categoryFormData.parentId ? "Örn: Hastaneler" : "Örn: SAĞLIK HİZMETLERİ"}
                        required
                      />
                    </div>

                    <div>
                      <Label htmlFor="categorySlug">URL Slug</Label>
                      <Input
                        id="categorySlug"
                        value={categoryFormData.slug}
                        onChange={(e) => setCategoryFormData({ ...categoryFormData, slug: e.target.value })}
                        placeholder={categoryFormData.parentId ? "Örn: hastaneler" : "Örn: saglik-hizmetleri"}
                        required
                      />
                    </div>

                    {!categoryFormData.parentId && (
                      <div>
                        <Label htmlFor="categoryIcon">İkon Adı</Label>
                        <Input
                          id="categoryIcon"
                          value={categoryFormData.icon}
                          onChange={(e) => setCategoryFormData({ ...categoryFormData, icon: e.target.value })}
                          placeholder="Örn: Heart, Building2, Car"
                          required
                        />
                        <p className="text-xs text-gray-500 mt-1">Lucide React ikon adları kullanın</p>
                      </div>
                    )}

                    {categoryFormData.parentId && (
                      <div>
                        <Label>Ana Kategori</Label>
                        <p className="text-sm text-gray-600">
                          {categories.find((c) => c.id === categoryFormData.parentId)?.name}
                        </p>
                      </div>
                    )}

                    <div>
                      <Label htmlFor="categoryOrder">Sıralama</Label>
                      <Input
                        id="categoryOrder"
                        type="number"
                        value={categoryFormData.order}
                        onChange={(e) =>
                          setCategoryFormData({ ...categoryFormData, order: Number.parseInt(e.target.value) })
                        }
                        required
                      />
                    </div>

                    <div className="flex items-center space-x-2">
                      <input
                        type="checkbox"
                        id="categoryActive"
                        checked={categoryFormData.isActive}
                        onChange={(e) => setCategoryFormData({ ...categoryFormData, isActive: e.target.checked })}
                        className="rounded"
                      />
                      <Label htmlFor="categoryActive">Aktif</Label>
                    </div>

                    <div className="flex justify-end space-x-2">
                      <Button type="button" variant="outline" onClick={() => setIsCategoryDialogOpen(false)}>
                        İptal
                      </Button>
                      <Button type="submit" className="bg-yellow-500 hover:bg-yellow-600 text-black">
                        {editingCategory ? "Güncelle" : "Ekle"}
                      </Button>
                    </div>
                  </form>
                </DialogContent>
              </Dialog>
            </div>

            {/* Categories List */}
            <Card>
              <CardHeader>
                <CardTitle>Kategoriler ({categories.filter((c) => !c.parentId).length} Ana Kategori)</CardTitle>
              </CardHeader>
              <CardContent>
                {getMainCategories().length === 0 ? (
                  <div className="text-center py-12">
                    <p className="text-gray-500 text-lg mb-4">Henüz hiç kategori eklenmemiş.</p>
                    <Button
                      onClick={() => openAddCategoryDialog()}
                      className="bg-yellow-500 hover:bg-yellow-600 text-black"
                    >
                      <Plus className="h-4 w-4 mr-2" />
                      İlk Kategoriyi Ekle
                    </Button>
                  </div>
                ) : (
                  <div className="space-y-2">
                    {getMainCategories().map((category) => (
                      <div key={category.id} className="border rounded-lg">
                        {/* Ana Kategori */}
                        <div className="p-4 hover:bg-gray-50">
                          <div className="flex items-center justify-between">
                            <div className="flex items-center space-x-3">
                              <button
                                onClick={() => toggleCategory(category.id)}
                                className="p-1 hover:bg-gray-200 rounded"
                              >
                                {expandedCategories.has(category.id) ? (
                                  <ChevronDown className="h-4 w-4" />
                                ) : (
                                  <ChevronRight className="h-4 w-4" />
                                )}
                              </button>
                              <div className="flex items-center space-x-2">
                                <span className="text-lg font-semibold">{category.name}</span>
                                {!category.isActive && <Badge variant="secondary">Pasif</Badge>}
                                <Badge variant="outline">{getSubCategories(category.id).length} alt kategori</Badge>
                              </div>
                            </div>

                            <div className="flex items-center space-x-2">
                              <span className="text-sm text-gray-500">Sıra: {category.order}</span>
                              <Button size="sm" variant="outline" onClick={() => openAddCategoryDialog(category.id)}>
                                <Plus className="h-4 w-4" />
                              </Button>
                              <Button size="sm" variant="outline" onClick={() => handleEditCategory(category)}>
                                <Edit className="h-4 w-4" />
                              </Button>
                              <Button
                                size="sm"
                                variant="outline"
                                onClick={() => handleDeleteCategory(category.id)}
                                className="text-red-600 hover:text-red-700"
                              >
                                <Trash2 className="h-4 w-4" />
                              </Button>
                            </div>
                          </div>

                          <div className="mt-2 text-sm text-gray-600 ml-7">
                            <p>
                              <strong>Slug:</strong> {category.slug} | <strong>İkon:</strong> {category.icon}
                            </p>
                          </div>
                        </div>

                        {/* Alt Kategoriler */}
                        {expandedCategories.has(category.id) && (
                          <div className="border-t bg-gray-50">
                            {getSubCategories(category.id).length === 0 ? (
                              <div className="p-4 text-center text-gray-500">
                                <p className="mb-2">Bu kategoride henüz alt kategori yok.</p>
                                <Button
                                  size="sm"
                                  onClick={() => openAddCategoryDialog(category.id)}
                                  className="bg-yellow-500 hover:bg-yellow-600 text-black"
                                >
                                  <Plus className="h-4 w-4 mr-2" />
                                  İlk Alt Kategoriyi Ekle
                                </Button>
                              </div>
                            ) : (
                              <div className="p-2">
                                {getSubCategories(category.id).map((subCategory) => (
                                  <div
                                    key={subCategory.id}
                                    className="flex items-center justify-between p-2 hover:bg-white rounded"
                                  >
                                    <div className="flex items-center space-x-2 ml-4">
                                      <span className="text-gray-400">└</span>
                                      <span className="font-medium">{subCategory.name}</span>
                                      {!subCategory.isActive && (
                                        <Badge variant="secondary" className="text-xs">
                                          Pasif
                                        </Badge>
                                      )}
                                    </div>

                                    <div className="flex items-center space-x-2">
                                      <span className="text-xs text-gray-500">Sıra: {subCategory.order}</span>
                                      <Button
                                        size="sm"
                                        variant="outline"
                                        onClick={() => handleEditCategory(subCategory)}
                                      >
                                        <Edit className="h-3 w-3" />
                                      </Button>
                                      <Button
                                        size="sm"
                                        variant="outline"
                                        onClick={() => handleDeleteCategory(subCategory.id)}
                                        className="text-red-600 hover:text-red-700"
                                      >
                                        <Trash2 className="h-3 w-3" />
                                      </Button>
                                    </div>
                                  </div>
                                ))}
                              </div>
                            )}
                          </div>
                        )}
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          {/* Site Ayarları Tab */}
          <TabsContent value="settings" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Settings className="h-5 w-5 mr-2" />
                  Site Ayarları
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                {/* Logo ve Site Adı */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <Label htmlFor="siteName">Site Adı</Label>
                    <Input
                      id="siteName"
                      placeholder="Örn: izmirrehber"
                      value={siteSettings.siteName}
                      onChange={(e) => setSiteSettings({ ...siteSettings, siteName: e.target.value })}
                    />
                    <p className="text-sm text-gray-500 mt-1">Header'da görünecek site adı</p>
                  </div>

                  <div>
                    <Label htmlFor="logo">Logo</Label>
                    <div className="space-y-2">
                      <Input
                        id="logo"
                        type="file"
                        accept="image/*"
                        onChange={(e) => {
                          const file = e.target.files?.[0]
                          if (file) {
                            const reader = new FileReader()
                            reader.onload = (event) => {
                              setSiteSettings({ ...siteSettings, logo: event.target?.result as string })
                            }
                            reader.readAsDataURL(file)
                          }
                        }}
                      />
                      <p className="text-xs text-gray-500">PNG veya SVG formatında logo yükleyebilirsiniz.</p>
                      {siteSettings.logo && (
                        <div className="mt-2">
                          <img
                            src={siteSettings.logo || "/placeholder.svg"}
                            alt="Logo Önizleme"
                            className="h-12 w-auto object-contain border rounded"
                          />
                          <Button
                            type="button"
                            variant="outline"
                            size="sm"
                            className="mt-1 bg-transparent"
                            onClick={() => setSiteSettings({ ...siteSettings, logo: "" })}
                          >
                            Logoyu Kaldır
                          </Button>
                        </div>
                      )}
                    </div>
                  </div>
                </div>

                {/* Hero Arkaplan Fotoğrafı */}
                <div>
                  <Label htmlFor="heroImage">Ana Sayfa Arkaplan Fotoğrafı</Label>
                  <div className="space-y-2">
                    <Input
                      id="heroImage"
                      type="file"
                      accept="image/*"
                      onChange={(e) => {
                        const file = e.target.files?.[0]
                        if (file) {
                          const reader = new FileReader()
                          reader.onload = (event) => {
                            setSiteSettings({ ...siteSettings, heroImage: event.target?.result as string })
                          }
                          reader.readAsDataURL(file)
                        }
                      }}
                    />
                    <p className="text-xs text-gray-500">
                      JPG veya PNG formatında arkaplan fotoğrafı yükleyebilirsiniz. (Önerilen boyut: 1200x600px)
                    </p>
                    {siteSettings.heroImage && (
                      <div className="mt-2">
                        <img
                          src={siteSettings.heroImage || "/placeholder.svg"}
                          alt="Hero Arkaplan Önizleme"
                          className="w-full h-32 object-cover rounded-lg border"
                        />
                        <Button
                          type="button"
                          variant="outline"
                          size="sm"
                          className="mt-1 bg-transparent"
                          onClick={() => setSiteSettings({ ...siteSettings, heroImage: "" })}
                        >
                          Arkaplan Fotoğrafını Kaldır
                        </Button>
                      </div>
                    )}
                  </div>
                </div>

                {/* İletişim Bilgileri */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <Label htmlFor="sitePhone">Site Telefon Numarası</Label>
                    <div className="relative">
                      <Phone className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                      <Input
                        id="sitePhone"
                        placeholder="Örn: 0232 123 45 67"
                        className="pl-10"
                        value={siteSettings.phone}
                        onChange={(e) => setSiteSettings({ ...siteSettings, phone: e.target.value })}
                      />
                    </div>
                    <p className="text-sm text-gray-500 mt-1">Header'da görünecek telefon numarası</p>
                  </div>

                  <div>
                    <Label htmlFor="siteEmail">Site E-posta Adresi</Label>
                    <div className="relative">
                      <Mail className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                      <Input
                        id="siteEmail"
                        type="email"
                        placeholder="Örn: info@izmirrehber.com"
                        className="pl-10"
                        value={siteSettings.email}
                        onChange={(e) => setSiteSettings({ ...siteSettings, email: e.target.value })}
                      />
                    </div>
                    <p className="text-sm text-gray-500 mt-1">İletişim için kullanılacak e-posta adresi</p>
                  </div>
                </div>

                <div className="flex justify-end">
                  <Button onClick={handleSaveSettings} className="bg-yellow-500 hover:bg-yellow-600 text-black">
                    Ayarları Kaydet
                  </Button>
                </div>

                {/* Önizleme */}
                <div className="border-t pt-6">
                  <h3 className="text-lg font-semibold mb-4">Önizleme</h3>

                  {/* Header Önizleme */}
                  <div className="bg-white border rounded-lg mb-4">
                    <div className="bg-gray-100 p-2">
                      <div className="flex justify-between items-center text-sm">
                        <div className="flex items-center space-x-4">
                          <span className="flex items-center">
                            <Phone className="h-4 w-4 mr-1" />
                            <span className="text-gray-500">{siteSettings.phone || "Telefon numarası eklenecek"}</span>
                          </span>
                          {siteSettings.email && (
                            <span className="flex items-center">
                              <Mail className="h-4 w-4 mr-1" />
                              <span className="text-gray-500">{siteSettings.email}</span>
                            </span>
                          )}
                        </div>
                      </div>
                    </div>
                    <div className="p-4 flex items-center">
                      {siteSettings.logo ? (
                        <img src={siteSettings.logo || "/placeholder.svg"} alt="Logo" className="h-8 w-auto mr-4" />
                      ) : (
                        <div className="h-8 w-8 bg-yellow-500 rounded flex items-center justify-center mr-4">
                          <span className="text-white font-bold text-sm">İR</span>
                        </div>
                      )}
                      <span className="text-gray-600">{siteSettings.siteName}</span>
                    </div>
                  </div>

                  {/* Hero Önizleme */}
                  <div className="relative bg-gray-800 rounded-lg overflow-hidden h-48">
                    {siteSettings.heroImage ? (
                      <img
                        src={siteSettings.heroImage || "/placeholder.svg"}
                        alt="Hero Arkaplan"
                        className="w-full h-full object-cover"
                      />
                    ) : (
                      <div className="w-full h-full bg-gradient-to-r from-blue-600 to-purple-600"></div>
                    )}
                    <div className="absolute inset-0 bg-black bg-opacity-40 flex items-center justify-center">
                      <div className="text-center text-white">
                        <h2 className="text-2xl font-bold mb-2">NASIL YARDIMCI OLABİLİRİZ?</h2>
                        <p className="text-sm">Hero Bölümü Önizleme</p>
                      </div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}
