"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Search, MapPin, Star, Phone, Mail, ArrowLeft, Building2 } from "lucide-react"
import Image from "next/image"

interface Company {
  id: number
  name: string
  category: string
  description: string
  phone: string
  email: string
  address: string
  image: string
  rating: number
  reviews: number
  isGold: boolean
  joinDate: string
}

// Kategori verilerini tanımla
const categoryData: { [key: string]: { name: string; subcategories: string[]; count: number } } = {
  "bankalar-ve-finansal-hizmetler": {
    name: "BANKALAR VE FİNANSAL HİZMETLER",
    count: 0,
    subcategories: [
      "Bankalar",
      "Sigorta Şirketleri",
      "Finansal Danışmanlık",
      "Kredi Kuruluşları",
      "Yatırım Danışmanlığı",
      "Muhasebe Ofisleri",
      "Mali Müşavirlik",
      "Döviz Büroları",
    ],
  },
  "bilgisayar-elektronik": {
    name: "BİLGİSAYAR - ELEKTRONİK",
    count: 162,
    subcategories: [
      "Bilgisayar Satış ve Servisi",
      "Yazılım Geliştirme",
      "Web Tasarım",
      "Elektronik Eşya",
      "Cep Telefonu",
      "Bilgisayar Aksesuarları",
      "Oyun Konsolları",
      "Ses Sistemleri",
      "Güvenlik Kameraları",
      "Ağ Sistemleri",
    ],
  },
  "hizmet-sektoru": {
    name: "HİZMET SEKTÖRÜ",
    count: 298,
    subcategories: [
      "Temizlik Hizmetleri",
      "Güvenlik Hizmetleri",
      "Nakliye ve Taşımacılık",
      "Kurye Hizmetleri",
      "Teknik Servis",
      "Tadilat ve Dekorasyon",
      "Bahçıvanlık",
      "Elektrikçi",
      "Tesisatçı",
      "Boyacı",
      "Cam Balkon",
      "Çilingir",
      "Asansör Servisi",
      "Klima Servisi",
      "Beyaz Eşya Servisi",
      "Oto Elektrikçi",
      "Oto Tamircisi",
      "Lastik Servisi",
      "Oto Yıkama",
      "Çekici Hizmetleri",
    ],
  },
  "insaat-ve-yapi": {
    name: "İNŞAAT VE YAPI",
    count: 0,
    subcategories: [
      "İnşaat Firmaları",
      "Mimarlık Büroları",
      "İç Mimarlık",
      "Peyzaj Mimarlığı",
      "Yapı Denetim",
      "Yapı Malzemeleri",
      "Çelik Konstrüksiyon",
      "Cam ve Ayna",
      "Boya ve Badana",
      "Seramik ve Fayans",
      "Parke ve Laminat",
      "İzolasyon",
      "Çatı Sistemleri",
      "Kapı ve Pencere",
    ],
  },
  "saglik-hizmetleri": {
    name: "SAĞLIK HİZMETLERİ",
    count: 0,
    subcategories: [
      "Hastaneler",
      "Özel Klinikler",
      "Diş Hekimleri",
      "Eczaneler",
      "Laboratuvarlar",
      "Fizik Tedavi",
      "Psikolog",
      "Diyetisyen",
      "Veteriner Hekimler",
      "Optisyen",
      "İşitme Cihazları",
      "Tıbbi Cihazlar",
      "Ambulans Hizmetleri",
      "Evde Bakım",
    ],
  },
  egitim: {
    name: "EĞİTİM",
    count: 0,
    subcategories: [
      "Okullar",
      "Üniversiteler",
      "Dershaneler",
      "Özel Dersler",
      "Dil Kursları",
      "Bilgisayar Kursları",
      "Sanat Kursları",
      "Müzik Kursları",
      "Dans Kursları",
      "Spor Kursları",
      "Sürücü Kursları",
      "Meslek Kursları",
      "Anaokulu",
      "Kreş",
    ],
  },
  "turizm-ve-otel": {
    name: "TURİZM VE OTEL",
    count: 0,
    subcategories: [
      "Oteller",
      "Pansiyonlar",
      "Apart Oteller",
      "Tatil Köyleri",
      "Seyahat Acenteleri",
      "Tur Operatörleri",
      "Rehberlik Hizmetleri",
      "Araç Kiralama",
      "Tekne Turları",
      "Günübirlik Turlar",
      "Kültür Turları",
      "Doğa Turları",
      "Kongre Organizasyonu",
      "Etkinlik Organizasyonu",
    ],
  },
  "yeme-icme": {
    name: "YEME İÇME",
    count: 0,
    subcategories: [
      "Restoranlar",
      "Kafeler",
      "Fast Food",
      "Pizzacılar",
      "Dönerci",
      "Balık Restoranları",
      "Et Restoranları",
      "Vejeteryan Restoranları",
      "Pastaneler",
      "Dondurma",
      "Çay Bahçeleri",
      "Nargile Kafeler",
      "Barlar",
      "Gece Kulüpleri",
      "Catering Hizmetleri",
    ],
  },
  otomotiv: {
    name: "OTOMOTİV",
    count: 0,
    subcategories: [
      "Otomobil Bayileri",
      "İkinci El Araç",
      "Oto Galeri",
      "Oto Ekspertiz",
      "Oto Sigorta",
      "Oto Finans",
      "Oto Aksesuar",
      "Lastik Bayileri",
      "Akü Bayileri",
      "Cam Filmi",
      "Araç Modifikasyon",
      "Motorsiklet",
      "Bisiklet",
      "Yedek Parça",
    ],
  },
  emlak: {
    name: "EMLAK",
    count: 0,
    subcategories: [
      "Emlak Ofisleri",
      "Gayrimenkul Danışmanlığı",
      "Emlak Değerleme",
      "İnşaat Firmaları",
      "Konut Projeleri",
      "Ticari Emlak",
      "Arsa Satışı",
      "Kiralık Daireler",
      "Satılık Daireler",
      "Villa Satışı",
      "Yazlık Satışı",
      "Dükkan Kiralama",
      "Ofis Kiralama",
      "Depo Kiralama",
    ],
  },
  "guzellik-ve-bakim": {
    name: "GÜZELLİK VE BAKIM",
    count: 0,
    subcategories: [
      "Kuaförler",
      "Güzellik Salonları",
      "Estetik Merkezleri",
      "Masaj Salonları",
      "Solaryum",
      "Nail Art",
      "Kaş Tasarım",
      "Kalıcı Makyaj",
      "Lazer Epilasyon",
      "Cilt Bakımı",
      "Saç Ekimi",
      "Berber",
      "Erkek Kuaförü",
      "Gelin Kuaförü",
    ],
  },
  "spor-ve-eglence": {
    name: "SPOR VE EĞLENCE",
    count: 0,
    subcategories: [
      "Spor Salonları",
      "Fitness Merkezleri",
      "Yüzme Havuzları",
      "Tenis Kortları",
      "Futbol Sahaları",
      "Basketbol Sahaları",
      "Voleybol Sahaları",
      "Bowling",
      "Bilardo Salonları",
      "Sinema",
      "Tiyatro",
      "Konser Salonları",
      "Eğlence Merkezleri",
      "Oyun Salonları",
    ],
  },
  "kultur-ve-sanat": {
    name: "KÜLTÜR VE SANAT",
    count: 0,
    subcategories: [
      "Müzeler",
      "Sanat Galerileri",
      "Kültür Merkezleri",
      "Kütüphaneler",
      "Sanat Atölyeleri",
      "Müzik Stüdyoları",
      "Dans Stüdyoları",
      "Fotoğraf Stüdyoları",
      "Seramik Atölyeleri",
      "Resim Kursları",
      "Heykel Atölyeleri",
      "El Sanatları",
      "Antika Dükkanları",
      "Kitap Mağazaları",
    ],
  },
  "moda-ve-giyim": {
    name: "MODA VE GİYİM",
    count: 0,
    subcategories: [
      "Giyim Mağazaları",
      "Ayakkabı Mağazaları",
      "Çanta ve Aksesuar",
      "Takı Mağazaları",
      "Saat Mağazaları",
      "Gözlük Mağazaları",
      "İç Giyim",
      "Spor Giyim",
      "Çocuk Giyim",
      "Bebek Giyim",
      "Gelinlik",
      "Damatlık",
      "Abiye",
      "Terzi",
    ],
  },
  "ev-ve-bahce": {
    name: "EV VE BAHÇE",
    count: 0,
    subcategories: [
      "Mobilya Mağazaları",
      "Ev Dekorasyon",
      "Halı ve Kilim",
      "Perde ve Jaluzi",
      "Aydınlatma",
      "Mutfak Eşyaları",
      "Banyo Aksesuarları",
      "Bahçe Mobilyaları",
      "Bahçe Aletleri",
      "Çiçekçiler",
      "Peyzaj",
      "Havuz Sistemleri",
      "Barbekü",
      "Şömine",
    ],
  },
  hayvanlar: {
    name: "HAYVANLAR",
    count: 0,
    subcategories: [
      "Pet Shop",
      "Veteriner Klinikleri",
      "Hayvan Bakım",
      "Köpek Eğitimi",
      "Hayvan Pansiyonu",
      "Akvaryum",
      "Kuş Mağazaları",
      "Kedi Malzemeleri",
      "Köpek Malzemeleri",
      "Hayvan Maması",
      "Hayvan Oyuncakları",
      "Hayvan Taşıma",
      "Hayvan Berber",
      "Hayvan Fotoğrafçısı",
    ],
  },
  "hobi-ve-el-sanatlari": {
    name: "HOBI VE EL SANATLARI",
    count: 0,
    subcategories: [
      "Hobi Mağazaları",
      "El Sanatları Malzemeleri",
      "Maket Malzemeleri",
      "Boyama Malzemeleri",
      "Dikiş Malzemeleri",
      "Örgü Malzemeleri",
      "Takı Yapım",
      "Seramik Malzemeleri",
      "Ahşap İşleri",
      "Metal İşleri",
      "Cam İşleri",
      "Kağıt İşleri",
      "Koleksiyon",
      "Antika",
    ],
  },
  "kargo-ve-nakliye": {
    name: "KARGO VE NAKLİYE",
    count: 0,
    subcategories: [
      "Kargo Firmaları",
      "Nakliye Firmaları",
      "Evden Eve Nakliyat",
      "Ofis Taşıma",
      "Uluslararası Nakliyat",
      "Lojistik Hizmetleri",
      "Depolama Hizmetleri",
      "Kurye Hizmetleri",
      "Moto Kurye",
      "Bisiklet Kurye",
      "Acil Kargo",
      "Soğuk Zincir",
      "Özel Eşya Taşıma",
      "Araç Çekici",
    ],
  },
  "medya-ve-iletisim": {
    name: "MEDYA VE İLETİŞİM",
    count: 0,
    subcategories: [
      "Gazete ve Dergiler",
      "Radyo Kanalları",
      "TV Kanalları",
      "Reklam Ajansları",
      "Halkla İlişkiler",
      "Sosyal Medya",
      "Web Tasarım",
      "Grafik Tasarım",
      "Fotoğrafçılık",
      "Video Prodüksiyon",
      "Ses Kayıt",
      "Çeviri Hizmetleri",
      "Basım ve Yayın",
      "Dijital Pazarlama",
    ],
  },
  "sosyal-hizmetler": {
    name: "SOSYAL HİZMETLER",
    count: 0,
    subcategories: [
      "Yaşlı Bakım",
      "Hasta Bakım",
      "Çocuk Bakım",
      "Temizlik Hizmetleri",
      "Yemek Servisi",
      "Güvenlik Hizmetleri",
      "Danışmanlık",
      "Hukuki Danışmanlık",
      "Psikolojik Danışmanlık",
      "Aile Danışmanlığı",
      "Evlilik Danışmanlığı",
      "Kariyer Danışmanlığı",
      "Eğitim Danışmanlığı",
      "Sosyal Yardım",
    ],
  },
  teknoloji: {
    name: "TEKNOLOJİ",
    count: 0,
    subcategories: [
      "Yazılım Geliştirme",
      "Mobil Uygulama",
      "Web Geliştirme",
      "E-ticaret",
      "Dijital Pazarlama",
      "SEO Hizmetleri",
      "Bulut Hizmetleri",
      "Veri Analizi",
      "Yapay Zeka",
      "Blockchain",
      "Siber Güvenlik",
      "Ağ Sistemleri",
      "Sunucu Hizmetleri",
      "IT Danışmanlığı",
    ],
  },
  ulasim: {
    name: "ULAŞIM",
    count: 0,
    subcategories: [
      "Taksi Hizmetleri",
      "Özel Şoför",
      "Araç Kiralama",
      "Minibüs Hizmetleri",
      "Otobüs Hizmetleri",
      "Havalimanı Transfer",
      "Şehir İçi Ulaşım",
      "Şehirler Arası",
      "Turist Taşımacılığı",
      "VIP Transfer",
      "Ambulans Hizmetleri",
      "Cenaze Nakil",
      "Hasta Nakil",
      "Öğrenci Servisi",
    ],
  },
  "uretim-ve-sanayi": {
    name: "ÜRETİM VE SANAYİ",
    count: 0,
    subcategories: [
      "Gıda Üretimi",
      "Tekstil Üretimi",
      "Metal İşleri",
      "Plastik Üretimi",
      "Kimya Sanayi",
      "İnşaat Malzemeleri",
      "Makine İmalatı",
      "Elektronik Üretimi",
      "Otomotiv Yan Sanayi",
      "Ambalaj Üretimi",
      "Kağıt Üretimi",
      "Cam Üretimi",
      "Seramik Üretimi",
      "Enerji Üretimi",
    ],
  },
  "ziraat-ve-hayvancilik": {
    name: "ZIRAAT VE HAYVANCILIK",
    count: 0,
    subcategories: [
      "Tarım Ürünleri",
      "Hayvancılık",
      "Sera İşletmeciliği",
      "Meyve Üretimi",
      "Sebze Üretimi",
      "Tahıl Üretimi",
      "Süt Üretimi",
      "Et Üretimi",
      "Bal Üretimi",
      "Çiçek Üretimi",
      "Fidancılık",
      "Tohum Üretimi",
      "Gübre Üretimi",
      "Tarım Makineleri",
    ],
  },
}

export default function CategoryPage({ params }: { params: { slug: string } }) {
  const [searchTerm, setSearchTerm] = useState("")
  const [selectedSubcategory, setSelectedSubcategory] = useState<string | null>(null)

  // Örnek veriler - gerçek uygulamada API'den gelecek
  const companies: Company[] = []

  const category = categoryData[params.slug]

  if (!category) {
    return <div>Kategori bulunamadı</div>
  }

  const filteredCompanies = companies.filter(
    (company) =>
      company.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      company.description.toLowerCase().includes(searchTerm.toLowerCase()),
  )

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm">
        <div className="container mx-auto px-4 py-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <Button asChild variant="outline">
                <a href="/" className="flex items-center">
                  <ArrowLeft className="h-4 w-4 mr-2" />
                  Ana Sayfa
                </a>
              </Button>
              <div>
                <h1 className="text-2xl font-bold text-gray-900">{category.name}</h1>
                <p className="text-gray-600">{category.count} işletme bulundu</p>
              </div>
            </div>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-4 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
          {/* Sidebar - Alt Kategoriler */}
          <div className="lg:col-span-1">
            <Card>
              <CardContent className="p-0">
                <div className="bg-slate-700 text-white p-4">
                  <h2 className="font-bold flex items-center">
                    <Building2 className="h-5 w-5 mr-2" />
                    ALT KATEGORİLER
                  </h2>
                </div>
                <div className="p-4">
                  <div className="space-y-2">
                    <button
                      onClick={() => setSelectedSubcategory(null)}
                      className={`w-full text-left py-2 px-3 rounded text-sm transition-colors ${
                        selectedSubcategory === null
                          ? "bg-yellow-500 text-black font-medium"
                          : "text-gray-700 hover:text-yellow-500 hover:bg-gray-50"
                      }`}
                    >
                      Tümü ({category.count})
                    </button>
                    {category.subcategories.map((subcat, index) => (
                      <button
                        key={index}
                        onClick={() => setSelectedSubcategory(subcat)}
                        className={`w-full text-left py-2 px-3 rounded text-sm transition-colors ${
                          selectedSubcategory === subcat
                            ? "bg-yellow-500 text-black font-medium"
                            : "text-gray-700 hover:text-yellow-500 hover:bg-gray-50"
                        }`}
                      >
                        {subcat} (0)
                      </button>
                    ))}
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Main Content */}
          <div className="lg:col-span-3">
            {/* Search */}
            <Card className="mb-8">
              <CardContent className="p-6">
                <div className="flex flex-col md:flex-row gap-4">
                  <div className="flex-1 relative">
                    <Search className="absolute left-3 top-3 h-5 w-5 text-gray-400" />
                    <Input
                      placeholder="İşletme adı veya açıklama ile ara..."
                      className="pl-10"
                      value={searchTerm}
                      onChange={(e) => setSearchTerm(e.target.value)}
                    />
                  </div>
                  <Button className="bg-yellow-500 hover:bg-yellow-600 text-black">Filtrele</Button>
                </div>
                {selectedSubcategory && (
                  <div className="mt-4">
                    <Badge variant="secondary" className="bg-yellow-100 text-yellow-800">
                      Seçili: {selectedSubcategory}
                      <button
                        onClick={() => setSelectedSubcategory(null)}
                        className="ml-2 text-yellow-600 hover:text-yellow-800"
                      >
                        ×
                      </button>
                    </Badge>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Companies Grid */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {filteredCompanies.map((company) => (
                <Card key={company.id} className="hover:shadow-lg transition-shadow">
                  <CardContent className="p-6">
                    <div className="flex items-start justify-between mb-4">
                      <Image
                        src={company.image || "/placeholder.svg"}
                        alt={company.name}
                        width={60}
                        height={60}
                        className="rounded-lg"
                      />
                      {company.isGold && <Badge className="bg-yellow-500 text-black">GOLD</Badge>}
                    </div>

                    <h3 className="text-lg font-semibold mb-2">{company.name}</h3>
                    <p className="text-sm text-gray-600 mb-2">{company.category}</p>
                    <p className="text-sm text-gray-500 mb-4 line-clamp-3">{company.description}</p>

                    <div className="space-y-2 mb-4">
                      <div className="flex items-center text-sm text-gray-600">
                        <Phone className="h-4 w-4 mr-2" />
                        {company.phone}
                      </div>
                      <div className="flex items-center text-sm text-gray-600">
                        <Mail className="h-4 w-4 mr-2" />
                        {company.email}
                      </div>
                      <div className="flex items-center text-sm text-gray-600">
                        <MapPin className="h-4 w-4 mr-2" />
                        {company.address}
                      </div>
                    </div>

                    <div className="flex items-center justify-between">
                      <div className="flex items-center">
                        <Star className="h-4 w-4 text-yellow-400 fill-current" />
                        <span className="text-sm ml-1">{company.rating}</span>
                        <span className="text-xs text-gray-500 ml-1">({company.reviews})</span>
                      </div>
                      <Button size="sm" className="bg-yellow-500 hover:bg-yellow-600 text-black">
                        Detaylar
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>

            {filteredCompanies.length === 0 && (
              <div className="text-center py-12">
                <Building2 className="h-16 w-16 text-gray-300 mx-auto mb-4" />
                <h3 className="text-lg font-semibold text-gray-600 mb-2">
                  {selectedSubcategory
                    ? `${selectedSubcategory} kategorisinde henüz işletme bulunmuyor.`
                    : `${category.name} kategorisinde henüz işletme bulunmuyor.`}
                </h3>
                <p className="text-gray-400 text-sm mt-2">İşletme eklemek için admin panelini kullanın.</p>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  )
}
