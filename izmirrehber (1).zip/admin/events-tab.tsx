"use client"

import type React from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog"
import { Label } from "@/components/ui/label"
import { Trash2, Edit, Plus, Calendar, MapPin, Clock, Users, Building2 } from "lucide-react"

interface Event {
  id: number
  title: string
  category: string
  description: string
  date: string
  time: string
  location: string
  organizer: string
  image: string
  price: string
  capacity: number
  registered: number
  isGold: boolean
  isFeatured: boolean
}

interface EventsTabProps {
  events: Event[]
  setEvents: (events: Event[]) => void
  isEventDialogOpen: boolean
  setIsEventDialogOpen: (open: boolean) => void
  editingEvent: Event | null
  setEditingEvent: (event: Event | null) => void
  eventFormData: any
  setEventFormData: (data: any) => void
  handleEventSubmit: (e: React.FormEvent) => void
  handleEditEvent: (event: Event) => void
  handleDeleteEvent: (id: number) => void
  openAddEventDialog: () => void
}

const eventCategories = [
  "Ticaret",
  "Müzik",
  "Sinema",
  "Gastronomi",
  "Kültür",
  "Spor",
  "Teknoloji",
  "Sanat",
  "Eğitim",
  "Sağlık",
]

export function EventsTab({
  events,
  isEventDialogOpen,
  setIsEventDialogOpen,
  editingEvent,
  eventFormData,
  setEventFormData,
  handleEventSubmit,
  handleEditEvent,
  handleDeleteEvent,
  openAddEventDialog,
}: EventsTabProps) {
  return (
    <div className="space-y-6">
      {/* Stats */}
      <div className="grid grid-cols-1 md:grid-cols-5 gap-6">
        <Card>
          <CardContent className="p-6">
            <div className="text-2xl font-bold text-yellow-600">{events.length}</div>
            <p className="text-gray-600">Toplam Etkinlik</p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-6">
            <div className="text-2xl font-bold text-yellow-600">{events.filter((e) => e.isGold).length}</div>
            <p className="text-gray-600">Gold Etkinlik</p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-6">
            <div className="text-2xl font-bold text-yellow-600">{events.filter((e) => e.isFeatured).length}</div>
            <p className="text-gray-600">Öne Çıkan</p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-6">
            <div className="text-2xl font-bold text-yellow-600">{new Set(events.map((e) => e.category)).size}</div>
            <p className="text-gray-600">Kategori</p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-6">
            <div className="text-2xl font-bold text-yellow-600">{events.reduce((sum, e) => sum + e.registered, 0)}</div>
            <p className="text-gray-600">Toplam Katılımcı</p>
          </CardContent>
        </Card>
      </div>

      {/* Add Event Button */}
      <div className="flex justify-end">
        <Dialog open={isEventDialogOpen} onOpenChange={setIsEventDialogOpen}>
          <DialogTrigger asChild>
            <Button onClick={openAddEventDialog} className="bg-yellow-500 hover:bg-yellow-600 text-black">
              <Plus className="h-4 w-4 mr-2" />
              Yeni Etkinlik Ekle
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>{editingEvent ? "Etkinlik Düzenle" : "Yeni Etkinlik Ekle"}</DialogTitle>
            </DialogHeader>
            <form onSubmit={handleEventSubmit} className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="eventTitle">Etkinlik Adı</Label>
                  <Input
                    id="eventTitle"
                    value={eventFormData.title}
                    onChange={(e) => setEventFormData({ ...eventFormData, title: e.target.value })}
                    required
                  />
                </div>
                <div>
                  <Label htmlFor="eventCategory">Kategori</Label>
                  <Select
                    value={eventFormData.category}
                    onValueChange={(value) => setEventFormData({ ...eventFormData, category: value })}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Kategori seçin" />
                    </SelectTrigger>
                    <SelectContent>
                      {eventCategories.map((category) => (
                        <SelectItem key={category} value={category}>
                          {category}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div>
                <Label htmlFor="eventDescription">Açıklama</Label>
                <Textarea
                  id="eventDescription"
                  value={eventFormData.description}
                  onChange={(e) => setEventFormData({ ...eventFormData, description: e.target.value })}
                  required
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="eventDate">Tarih</Label>
                  <Input
                    id="eventDate"
                    placeholder="Örn: 15-25 Mart 2024"
                    value={eventFormData.date}
                    onChange={(e) => setEventFormData({ ...eventFormData, date: e.target.value })}
                    required
                  />
                </div>
                <div>
                  <Label htmlFor="eventTime">Saat</Label>
                  <Input
                    id="eventTime"
                    placeholder="Örn: 10:00 - 18:00"
                    value={eventFormData.time}
                    onChange={(e) => setEventFormData({ ...eventFormData, time: e.target.value })}
                    required
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="eventLocation">Konum</Label>
                  <Input
                    id="eventLocation"
                    value={eventFormData.location}
                    onChange={(e) => setEventFormData({ ...eventFormData, location: e.target.value })}
                    required
                  />
                </div>
                <div>
                  <Label htmlFor="eventOrganizer">Organizatör</Label>
                  <Input
                    id="eventOrganizer"
                    value={eventFormData.organizer}
                    onChange={(e) => setEventFormData({ ...eventFormData, organizer: e.target.value })}
                    required
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="eventPrice">Fiyat</Label>
                  <Input
                    id="eventPrice"
                    placeholder="Örn: Ücretsiz, 50 TL, 25-100 TL"
                    value={eventFormData.price}
                    onChange={(e) => setEventFormData({ ...eventFormData, price: e.target.value })}
                    required
                  />
                </div>
                <div>
                  <Label htmlFor="eventCapacity">Kapasite</Label>
                  <Input
                    id="eventCapacity"
                    type="number"
                    value={eventFormData.capacity}
                    onChange={(e) => setEventFormData({ ...eventFormData, capacity: Number.parseInt(e.target.value) })}
                    required
                  />
                </div>
              </div>

              <div>
                <Label htmlFor="eventImage">Etkinlik Görseli</Label>
                <div className="space-y-2">
                  <Input
                    id="eventImage"
                    type="file"
                    accept="image/*"
                    onChange={(e) => {
                      const file = e.target.files?.[0]
                      if (file) {
                        const reader = new FileReader()
                        reader.onload = (event) => {
                          setEventFormData({ ...eventFormData, image: event.target?.result as string })
                        }
                        reader.readAsDataURL(file)
                      }
                    }}
                  />
                  <p className="text-xs text-gray-500">JPG, PNG veya GIF formatında görsel yükleyebilirsiniz.</p>
                  {eventFormData.image && (
                    <div className="mt-2">
                      <img
                        src={eventFormData.image || "/placeholder.svg"}
                        alt="Önizleme"
                        className="w-32 h-20 object-cover rounded-lg border"
                      />
                      <Button
                        type="button"
                        variant="outline"
                        size="sm"
                        className="mt-1 bg-transparent"
                        onClick={() => setEventFormData({ ...eventFormData, image: "" })}
                      >
                        Görseli Kaldır
                      </Button>
                    </div>
                  )}
                </div>
              </div>

              <div className="flex items-center space-x-4">
                <div className="flex items-center space-x-2">
                  <input
                    type="checkbox"
                    id="eventIsGold"
                    checked={eventFormData.isGold}
                    onChange={(e) => setEventFormData({ ...eventFormData, isGold: e.target.checked })}
                    className="rounded"
                  />
                  <Label htmlFor="eventIsGold">Gold Etkinlik</Label>
                </div>

                <div className="flex items-center space-x-2">
                  <input
                    type="checkbox"
                    id="eventIsFeatured"
                    checked={eventFormData.isFeatured}
                    onChange={(e) => setEventFormData({ ...eventFormData, isFeatured: e.target.checked })}
                    className="rounded"
                  />
                  <Label htmlFor="eventIsFeatured">Öne Çıkar</Label>
                </div>
              </div>

              <div className="flex justify-end space-x-2">
                <Button type="button" variant="outline" onClick={() => setIsEventDialogOpen(false)}>
                  İptal
                </Button>
                <Button type="submit" className="bg-yellow-500 hover:bg-yellow-600 text-black">
                  {editingEvent ? "Güncelle" : "Ekle"}
                </Button>
              </div>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      {/* Events List */}
      <Card>
        <CardHeader>
          <CardTitle>Etkinlikler ({events.length})</CardTitle>
        </CardHeader>
        <CardContent>
          {events.length === 0 ? (
            <div className="text-center py-12">
              <p className="text-gray-500 text-lg mb-4">Henüz hiç etkinlik eklenmemiş.</p>
              <Button onClick={openAddEventDialog} className="bg-yellow-500 hover:bg-yellow-600 text-black">
                <Plus className="h-4 w-4 mr-2" />
                İlk Etkinliği Ekle
              </Button>
            </div>
          ) : (
            <div className="space-y-4">
              {events.map((event) => (
                <div key={event.id} className="border rounded-lg p-4 hover:shadow-md transition-shadow">
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <div className="flex items-center space-x-2 mb-2">
                        <h3 className="text-lg font-semibold">{event.title}</h3>
                        {event.isGold && <Badge className="bg-yellow-500 text-black">GOLD</Badge>}
                        {event.isFeatured && <Badge className="bg-blue-500 text-white ml-2">ÖNE ÇIKAN</Badge>}
                      </div>
                      <p className="text-gray-600 mb-2">{event.category}</p>
                      <p className="text-sm text-gray-500 mb-3">{event.description}</p>

                      <div className="grid grid-cols-1 md:grid-cols-2 gap-2 text-sm text-gray-600 mb-3">
                        <div className="flex items-center">
                          <Calendar className="h-4 w-4 mr-1" />
                          {event.date}
                        </div>
                        <div className="flex items-center">
                          <Clock className="h-4 w-4 mr-1" />
                          {event.time}
                        </div>
                        <div className="flex items-center">
                          <MapPin className="h-4 w-4 mr-1" />
                          {event.location}
                        </div>
                        <div className="flex items-center">
                          <Building2 className="h-4 w-4 mr-1" />
                          {event.organizer}
                        </div>
                      </div>

                      <div className="flex items-center justify-between">
                        <div className="flex items-center space-x-4 text-sm text-gray-600">
                          <div className="flex items-center">
                            <Users className="h-4 w-4 mr-1" />
                            {event.registered}/{event.capacity} katılımcı
                          </div>
                          <div className="font-semibold text-yellow-600">{event.price}</div>
                        </div>
                      </div>
                    </div>

                    <div className="flex space-x-2 ml-4">
                      <Button size="sm" variant="outline" onClick={() => handleEditEvent(event)}>
                        <Edit className="h-4 w-4" />
                      </Button>
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => handleDeleteEvent(event.id)}
                        className="text-red-600 hover:text-red-700"
                      >
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  )
}
